$(document).ready(function() {
	matchFriends();
	$("label[name='btn_choose']").click(function() {
//		alert($(this).attr("accountinfo")); 
		if (confirm("Do you want to make friend with him ?")) {
			makeFriend($(this).attr("accountinfo"));
		} 
	});
});
function matchFriends() {
	$.ajax({
		type : "post",// 使用get方法访问后台
		async : false,
		dataType : "json",// 返回json格式的数据
		url : "seniorInfo/recommendateStudent",// 要访问的后台地址
		success : function(data) {
			console.dir(data);
			var number = data.length;
			if (number < 3) {
				for (number; number < 3; number++) {
					$(".student:eq(" + number + ")").hide();
				}
			}
			for(var i=0;i<data.length;i++){
				$(".student:eq(" + i + ") span:eq(0)").text(data[i].student.preferredName);
				for(var z=0;z<data[i].time.length;z++){
					var  d=new Date();
					 var shiqv = d.getTimezoneOffset()/60;
					var avaiTimeId = data[i].time[z].availableTimeDic.avaiTimeId;
					if(avaiTimeId == 1){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",1)+"-"+Time(shiqv,12,"PM",1));
					}
					if(avaiTimeId == 2){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",2)+"-"+Time(shiqv,12,"PM",2));
					}
					if(avaiTimeId == 3){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",3)+"-"+Time(shiqv,12,"PM",3));
					}
					if(avaiTimeId == 4){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",4)+"-"+Time(shiqv,12,"PM",4));
					}
					if(avaiTimeId == 5){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",5)+"-"+Time(shiqv,12,"PM",5));
					}
					if(avaiTimeId == 6){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"AM",6)+"-"+Time(shiqv,12,"AM",6));
					}
					if(avaiTimeId == 7){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",6)+"-"+Time(shiqv,12,"PM",6));
					}
					if(avaiTimeId == 8){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"AM",7)+"-"+Time(shiqv,12,"AM",7));
					}
					if(avaiTimeId == 9){
						$(".student:eq(" + i + ") span:eq(1)").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",7)+"-"+Time(shiqv,12,"PM",7));
					}
				/*	$(".student:eq(" + i + ") span:eq(1)").append(+"  ");*/
				}
				for(var z=0;z<data[i].interest.length;z++){
					$(".student:eq(" + i + ") span:eq(2)").append(data[i].interest[z].stuInterestDic.interestName+"  ");
				}
				$(".student:eq(" + i + ") span:eq(3)").text(data[i].student.memo);
				$(".student:eq(" + i + ") span:eq(4)").text(data[i].student.introduction);
				$(".student:eq(" + i + ") .btn-primary").attr("accountinfo",data[i].student.accountInfo.userId);
				
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
	});

}

function makeFriend(friendId) {
	$.ajax({
		type : "post",// 使用get方法访问后台
		async : false,
		dataType : "json",// 返回json格式的数据
		data:{
			"friendId":friendId
		},
		url : "seniorInfo/updateAccountInfo",// 要访问的后台地址
		success : function(data) {
			console.dir(data);
			window.location.href="seniors/SeniorsHomeReal.jsp";
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
	});
	



}

function Time(shiqv,xiaoshi,AmOrPm,xingqiji){
	var xiaoshi;
	var xingqiji;
	var str = "";
	if(AmOrPm=="PM"){
		xiaoshi = Number(xiaoshi)+12;
		xiaoshi = xiaoshi-(Number(shiqv)-(-8));
		if(xiaoshi>24){
			xingqiji = Number(xingqiji)+1;
			if(xingqiji>7){
				xingqiji = xingqiji-7;
			};
			xiaoshi = xiaoshi-24;
			if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
		}else{
			if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
			
		};
		
	}else{
		xiaoshi = (Number(xiaoshi)-(shiqv+8));
		if(xiaoshi<=0){
			xingqiji = Number(xingqiji)-1;
			if(xingqiji == 0){
				xingqiji = 7;
			}
			xiaoshi = 24+xiaoshi;
		}
		if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
	}
	
	return str;
	
};
function xingqi(xingqiji){
	var str = xingqiji;
	if(str == 1){
		str = "Monday";
	}
	if(str == 2){
		str = "Tuesday";
	}
	if(str == 3){
		str = "Wednesday";
	}
	if(str == 4){
		str = "Thursday";
	}
	if(str == 5){
		str = "Friday";
	}
	if(str == 6){
		str = "Saturday";
	}
	if(str == 7){
		str = "Sunday";
	}
	return str;
}