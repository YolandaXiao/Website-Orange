$(document).ready(function() {
	if($('input:radio[name="accountInfo.role"]:checked').val() == "seniors"){
		$("#inviteCode").hide();
	}
	$("#form").submit(function(){
		if(isEmailExist($(".form-control").eq(0).val())){
			if(isInvideExist($(".form-control").eq(2).val())){
				return true;
			}else{
				
				return false;
			}
			
		}else{
			return false;
		}
		
	});
	
	$("#inlineRadio2").click(function(){
		$("#inviteCode").hide();
	});
	$("#inlineRadio1").click(function(){
		$("#inviteCode").show();
	});
	$("#id_close").click(function(){
		$("#id_alert").css('display','none');
	});
	
});
/**
 * 是否存在邀请码
 * @param inviteCode
 * @returns
 */
function isInvideExist(inviteCode){
	if($('input:radio[name="accountInfo.role"]:checked').val() == "seniors"){
		return true;
	}
	var tag = false;
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		data:{
			"inviteCode.code":inviteCode
		},
		url : "register/isInvideCodeExist",// 要访问的后台地址
		success : function(data) {
			if(data.success){
				tag = true;
				$('#id_alert').css('display','none');
			}else{
				$('#id_alert').css('display','block');
				$('#id_alert span').text('The inviteCode has bean invalid or used! Please change!');
			}
			
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
	return tag;
}

function isEmailExist(userName){
	if($('input:radio[name="accountInfo.role"]:checked').val() == "student") {
		if($("#inviteCode").val() == ""){
			$('#id_alert').css('display','block');
			$('#id_alert span').text('You must enter the inviteCode as you have seleceted student！');
			return false;
		}
	}
	var tag = false;
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		data:{
			"accountInfo.userName":userName
		},
		url : "register/isEmailExist",// 要访问的后台地址
		success : function(data) {
			if(data.success){
				tag = true;
				$('#id_alert').css('display','none');
			}else{
				$('#id_alert').css('display','block');
				$('#id_alert span').text('The email has registered! please login directly or change email!');
			}
			
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
	return tag;
}
