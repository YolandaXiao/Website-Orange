var globleData = "";
$(document).ready(function() {
	interestList();
	seniorInfo();
	availableTimeList();
	
	$("#submit").click(function(){
		$("#submit1").click();
	});
	
	$("#form").submit(function(){
		return checkForm();
	});
	 var  d=new Date();
	 var shiqv = d.getTimezoneOffset()/60;
	$("#mon").text(Time(shiqv,8,"PM",1)+"-"+Time(shiqv,12,"PM",1));
	$("#tues").text(Time(shiqv,8,"PM",2)+"-"+Time(shiqv,12,"PM",2));
	$("#wed").text(Time(shiqv,8,"PM",3)+"-"+Time(shiqv,12,"PM",3));
	$("#thurs").text(Time(shiqv,8,"PM",4)+"-"+Time(shiqv,12,"PM",4));
	$("#fri").text(Time(shiqv,8,"PM",5)+"-"+Time(shiqv,12,"PM",5));
	$("#sat1").text(Time(shiqv,8,"AM",6)+"-"+Time(shiqv,12,"AM",6));
	$("#sat2").text(Time(shiqv,8,"PM",6)+"-"+Time(shiqv,12,"PM",6));
	$("#sun1").text(Time(shiqv,8,"AM",7)+"-"+Time(shiqv,12,"AM",7));
	$("#sun2").text(Time(shiqv,8,"PM",7)+"-"+Time(shiqv,12,"PM",7));
	
	for(var n = 1; n < 6; n ++) {
		$("#interest"+n).append("<option value=\"\" selected=\"selected\">Interest Tag "+n+"</option>");
	}
	for(var i=0;i<globleData.rows.length;i++){
		$("#interest1").append("<option value="+globleData.rows[i].interestId+">"+globleData.rows[i].interestName+"</option>");
	}
	$('#interest1').change(function(){ 
		$("#interest2").find("option").remove();
		$("#interest3").find("option").remove();
		$("#interest4").find("option").remove();
		$("#interest5").find("option").remove();
		$("#interest2").append("<option value=\"\" selected=\"selected\">Interest Tag 2</option>");
		$("#interest3").append("<option value=\"\" selected=\"selected\">Interest Tag 2</option>");
		$("#interest4").append("<option value=\"\" selected=\"selected\">Interest Tag 2</option>");
		$("#interest5").append("<option value=\"\" selected=\"selected\">Interest Tag 2</option>");
		var interest1 = $("#interest1 option:selected").val();
		for(var i=0;i<globleData.rows.length;i++){
			if(globleData.rows[i].interestId == interest1)
				continue;
			$("#interest2").append("<option value="+globleData.rows[i].interestId+">"+globleData.rows[i].interestName+"</option>");
		}
	});
	$('#interest2').change(function(){ 
		$("#interest3").find("option").remove();
		$("#interest4").find("option").remove();
		$("#interest5").find("option").remove();
		$("#interest3").append("<option value=\"\" selected=\"selected\">Interest Tag 3</option>");
		$("#interest4").append("<option value=\"\" selected=\"selected\">Interest Tag 4</option>");
		$("#interest5").append("<option value=\"\" selected=\"selected\">Interest Tag 5</option>");
		var interest1 = $("#interest1 option:selected").val();
		var interest2 = $("#interest2 option:selected").val();
		for(var i=0;i<globleData.rows.length;i++){
			if(globleData.rows[i].interestId == interest1 || globleData.rows[i].interestId == interest2 )
				continue;
			$("#interest3").append("<option value="+globleData.rows[i].interestId+">"+globleData.rows[i].interestName+"</option>");
		}
	});
	$('#interest3').change(function(){ 
		$("#interest4").find("option").remove();
		$("#interest5").find("option").remove();
		$("#interest4").append("<option value=\"\" selected=\"selected\">Interest Tag 4</option>");
		$("#interest5").append("<option value=\"\" selected=\"selected\">Interest Tag 5</option>");
		var interest1 = $("#interest1 option:selected").val();
		var interest2 = $("#interest2 option:selected").val();
		var interest3 = $("#interest3 option:selected").val();
		for(var i=0;i<globleData.rows.length;i++){
			if(globleData.rows[i].interestId == interest1 || globleData.rows[i].interestId == interest2 || globleData.rows[i].interestId == interest3 )
				continue;
			$("#interest4").append("<option value="+globleData.rows[i].interestId+">"+globleData.rows[i].interestName+"</option>");
		}
	});
	$('#interest4').change(function(){ 
		$("#interest5").find("option").remove();
		$("#interest5").append("<option value=\"\" selected=\"selected\">Interest Tag 5</option>");
		var interest1 = $("#interest1 option:selected").val();
		var interest2 = $("#interest2 option:selected").val();
		var interest3 = $("#interest3 option:selected").val();
		var interest4 = $("#interest4 option:selected").val();
		for(var i=0;i<globleData.rows.length;i++){
			if(globleData.rows[i].interestId == interest1 || globleData.rows[i].interestId == interest2 || globleData.rows[i].interestId == interest3 || globleData.rows[i].interestId == interest4 )
				continue;
			$("#interest5").append("<option value="+globleData.rows[i].interestId+">"+globleData.rows[i].interestName+"</option>");
		}
	});
	$("#id_close").click(function(){
		$("#id_alert").css('display','none');
	});
});
function seniorInfo(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "seniorInfo/findSeniorInfoBySession",// 要访问的后台地址
		success : function(data) {
			$("#emailAddress").val(data.seniorInfo.emailAddress);
			$("#nameCH").val(data.seniorInfo.nameCH);
			$("#preferredName").val(data.seniorInfo.preferredName);
			$("#nameCH").val(data.seniorInfo.nameCH);
			$("#namePinyin").val(data.seniorInfo.namePinyin);
			$("#password").val(data.seniorInfo.accountInfo.pwd);
			if(data.seniorInfo.gender=="female"){
				$("#gender1").attr("checked","checked");
			}else{
				$("#gender2").attr("checked","checked");
			}
			$("#birthday").val(data.seniorInfo.birthday);
			$("#skypeID").val(data.seniorInfo.skypeID);
			$("#memo").val(data.seniorInfo.memo);
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};
function interestListOfSenior(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "relationOfStudent_Interest/findRelationOfStudent_InterestBySession",// 要访问的后台地址
		success : function(data) {
			var relationOfStudent_Interests = data.relationOfStudent_Interests;
			for(i=0;i<relationOfStudent_Interests.length;i++){
				$("#interest").append(relationOfStudent_Interests[i].stuInterestDic.interestName+"   ");  
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};
function availableTimeList(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "relationOfStudent_Interest/findAvaiTimeOfStudentsBySession",// 要访问的后台地址
		success : function(data) {
			var avaiTimeOfStudents = data.avaiTimeOfStudents;
			var  d=new Date();
			 var shiqv = d.getTimezoneOffset()/60;
			for(var i=0;i<avaiTimeOfStudents.length;i++){
				var avaiTimeId = avaiTimeOfStudents[i].availableTimeDic.avaiTimeId;
				if(avaiTimeId == 1){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",1)+"-"+Time(shiqv,12,"PM",1));
				}
				if(avaiTimeId == 2){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",2)+"-"+Time(shiqv,12,"PM",2));
				}
				if(avaiTimeId == 3){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",3)+"-"+Time(shiqv,12,"PM",3));
				}
				if(avaiTimeId == 4){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",4)+"-"+Time(shiqv,12,"PM",4));
				}
				if(avaiTimeId == 5){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",5)+"-"+Time(shiqv,12,"PM",5));
				}
				if(avaiTimeId == 6){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"AM",6)+"-"+Time(shiqv,12,"AM",6));
				}
				if(avaiTimeId == 7){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",6)+"-"+Time(shiqv,12,"PM",6));
				}
				if(avaiTimeId == 8){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"AM",7)+"-"+Time(shiqv,12,"AM",7));
				}
				if(avaiTimeId == 9){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",7)+"-"+Time(shiqv,12,"PM",7));
				}
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};


function Time(shiqv,xiaoshi,AmOrPm,xingqiji){
	var xiaoshi;
	var xingqiji;
	var str = "";
	if(AmOrPm=="PM"){
		xiaoshi = Number(xiaoshi)+12;
		xiaoshi = xiaoshi-(Number(shiqv)-(-8));
		if(xiaoshi>24){
			xingqiji = Number(xingqiji)+1;
			if(xingqiji>7){
				xingqiji = xingqiji-7;
			};
			xiaoshi = xiaoshi-24;
			if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
		}else{
			if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
			
		};
		
	}else{
		xiaoshi = (Number(xiaoshi)-(shiqv+8));
		if(xiaoshi<=0){
			xingqiji = Number(xingqiji)-1;
			if(xingqiji == 0){
				xingqiji = 7;
			}
			xiaoshi = 24+xiaoshi;
		}
		if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
	}
	
	return str;
	
};
function xingqi(xingqiji){
	var str = xingqiji;
	if(str == 1){
		str = "Monday";
	}
	if(str == 2){
		str = "Tuesday";
	}
	if(str == 3){
		str = "Wednesday";
	}
	if(str == 4){
		str = "Thursday";
	}
	if(str == 5){
		str = "Friday";
	}
	if(str == 6){
		str = "Saturday";
	}
	if(str == 7){
		str = "Sunday";
	}
	return str;
}


/**
 * 显示爱好列表
 * @param interest1
 * @param interest2
 */
function interestList(){
	$("#interest1").find("option").remove();
	$("#interest2").find("option").remove();
	$("#interest3").find("option").remove();
	$("#interest4").find("option").remove();
	$("#interest5").find("option").remove();
		$.ajax({
			type : "post",// 使用get方法访问后台
			async: false,
			dataType : "json",// 返回json格式的数据
			data:{
				"interest1":0,
				"interest2":0
			},
			url : "stuInterestDic/interestList",// 要访问的后台地址
			success : function(data) {
				globleData = data;
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
			});
}
var errorNum = 0;
function checkForm(){
	$('#interest1').css('border','0px solid #ea6f7c');
	$('#interest2').css('border','0px solid #ea6f7c');
	$('#interest3').css('border','0px solid #ea6f7c');
	$('#interest4').css('border','0px solid #ea6f7c');
	$('#interest5').css('border','0px solid #ea6f7c');
	$('#id_avaliabletime').css('border','0px solid #ea6f7c');
	var errorNum = 0;
	if($("input[name='seniorInfo.birthday']").val()==""){
//		errorNum ++;
	}
	if($("select[name='seniorInfo.school'] option:selected").val()==""){
//			errorNum ++;
	}
	if($("select[name='region'] option:selected").val()==""||$("select[name='country'] option:selected").val()==""||$("select[name='city_state'] option:selected").val()==""){
//			errorNum ++;
	}
	if($("#interest1 option:selected").val()==""){
		errorNum ++;
		$('#interest1').css('border','1px solid #ea6f7c');
	}
	if($("#interest2 option:selected").val()==""){
		errorNum ++;
		$('#interest2').css('border','1px solid #ea6f7c');
	}
	if($("#interest3 option:selected").val()==""){
		errorNum ++;
		$('#interest3').css('border','1px solid #ea6f7c');
	}
	if($("#interest4 option:selected").val()==""){
		errorNum ++;
		$('#interest4').css('border','1px solid #ea6f7c');
	}
	if($("#interest5 option:selected").val()==""){
		errorNum ++;
		$('#interest5').css('border','1px solid #ea6f7c');
	}
	
	var str="";     
	$("input[name='availableTime']:checked").each(function(){     
	     str+=$(this).val();   
	});    
	if(str==""){
		errorNum ++;
		$('#id_avaliabletime').css('border','1px solid #ea6f7c');
	}
	if(errorNum > 0) {
		$('#id_alert').css('display','block');
		return false;
	}
}