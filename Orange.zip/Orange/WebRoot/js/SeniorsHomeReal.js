$(document).ready(function() {
	seniorFriendInfo();
	interestList();
	availableTimeList();
});
function seniorFriendInfo(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "seniorInfo/findSeniorFriendInfoBySession",// 要访问的后台地址
		success : function(data) {
			$("#nameCH").text(data.studentinfo.nameCH);
			$("#gender").text(data.studentinfo.gender);
			$("#email").text(data.studentinfo.accountInfo.userName);
			$("#skypeID").text(data.studentinfo.skypeID);
			$("#memo").text(data.studentinfo.memo);
			$("#introduction").text(data.studentinfo.introduction);
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};
function interestList(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "relationOfStudent_Interest/findRelationOfStudent_InterestBySession1",// 要访问的后台地址
		success : function(data) {
			var relationOfStudent_Interests = data.relationOfStudent_Interests;
			for(i=0;i<relationOfStudent_Interests.length;i++){
				$("#interest").append(relationOfStudent_Interests[i].stuInterestDic.interestName+"   ");  
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};
function availableTimeList(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "relationOfStudent_Interest/findAvaiTimeOfStudentsBySession1",// 要访问的后台地址
		success : function(data) {
			var avaiTimeOfStudents = data.avaiTimeOfStudents;
			var  d=new Date();
			 var shiqv = d.getTimezoneOffset()/60;
			for(var i=0;i<avaiTimeOfStudents.length;i++){
				var avaiTimeId = avaiTimeOfStudents[i].availableTimeDic.avaiTimeId;
				if(avaiTimeId == 1){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",1)+"-"+Time(shiqv,12,"PM",1));
				}
				if(avaiTimeId == 2){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",2)+"-"+Time(shiqv,12,"PM",2));
				}
				if(avaiTimeId == 3){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",3)+"-"+Time(shiqv,12,"PM",3));
				}
				if(avaiTimeId == 4){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",4)+"-"+Time(shiqv,12,"PM",4));
				}
				if(avaiTimeId == 5){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",5)+"-"+Time(shiqv,12,"PM",5));
				}
				if(avaiTimeId == 6){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"AM",6)+"-"+Time(shiqv,12,"AM",6));
				}
				if(avaiTimeId == 7){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",6)+"-"+Time(shiqv,12,"PM",6));
				}
				if(avaiTimeId == 8){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"AM",7)+"-"+Time(shiqv,12,"AM",7));
				}
				if(avaiTimeId == 9){
					$("#avaiTime").append("<br/>&nbsp&nbsp&nbsp&nbsp"+Time(shiqv,8,"PM",7)+"-"+Time(shiqv,12,"PM",7));
				}
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};


function Time(shiqv,xiaoshi,AmOrPm,xingqiji){
	var xiaoshi;
	var xingqiji;
	var str = "";
	if(AmOrPm=="PM"){
		xiaoshi = Number(xiaoshi)+12;
		xiaoshi = xiaoshi-(Number(shiqv)-(-8));
		if(xiaoshi>24){
			xingqiji = Number(xingqiji)+1;
			if(xingqiji>7){
				xingqiji = xingqiji-7;
			};
			xiaoshi = xiaoshi-24;
			if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
		}else{
			if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
			
		};
		
	}else{
		xiaoshi = (Number(xiaoshi)-(shiqv+8));
		if(xiaoshi<=0){
			xingqiji = Number(xingqiji)-1;
			if(xingqiji == 0){
				xingqiji = 7;
			}
			xiaoshi = 24+xiaoshi;
		}
		if(xiaoshi>12){
				str +=xiaoshi-12+"pm "+xingqi(xingqiji);
			}else{
				str +=xiaoshi+"am "+xingqi(xingqiji);
			};
	}
	
	return str;
	
};
function xingqi(xingqiji){
	var str = xingqiji;
	if(str == 1){
		str = "Monday";
	}
	if(str == 2){
		str = "Tuesday";
	}
	if(str == 3){
		str = "Wednesday";
	}
	if(str == 4){
		str = "Thursday";
	}
	if(str == 5){
		str = "Friday";
	}
	if(str == 6){
		str = "Saturday";
	}
	if(str == 7){
		str = "Sunday";
	}
	return str;
}


