$(document).ready(function() {
	seniorFriendInfo();
	
});
function seniorFriendInfo(){
	$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : "student/findStudentFriendInfoBySession",// 要访问的后台地址
		success : function(data) {
			console.dir(data);
		/*	if(!data.result) {
			}else {*/
				$("#nameCH").text(data.seniorInfo.nameCH);
				$("#gender").text(data.seniorInfo.gender);
				$("#province").text(data.seniorInfo.province);
				$("#country").text(data.seniorInfo.country);
				$("#email").text(data.seniorInfo.accountInfo.userName);
				$("#skypeID").text(data.seniorInfo.skypeID);
				$("#memo").text(data.seniorInfo.memo);
		//	}
			
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
		}
		});
};
