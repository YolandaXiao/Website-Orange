/**
 * 显示邀请码信息
 */
$(document).ready(function(){
	invitecodePagesAndList();
});

function invitecodePagesAndList() {
	var isClickOk=true;//判断的变量  
	$(function() {  
    $('#table_invitecode').datagrid({  
        title : '邀请码信息',  
        iconCls : 'icon-ok',  
        width : 1050,  
        pageSize : 10,//默认选择的分页是每页5行数据  
        pageList : [ 10, 15, 20 ],//可以选择的分页集合  
        nowrap : true,//设置为true，当数据长度超出列宽时将会自动截取  
        striped : true,//设置为true将交替显示行背景。  
        collapsible : true,//显示可折叠按钮  
        toolbar:"#easyui_toolbar",//在添加 增添、删除、修改操作的按钮要用到这个  
        url:'../inviteCode/findSomeInviteCodes',//url调用Action方法  
        loadMsg : '数据装载中......',  
        loadFilter: function(data){
			return data;
		},
        //singleSelect:true,//为true时只能选择单行 为了实现批量删除必须隐去  
        fitColumns:true,//允许表格自动缩放，以适应父容器  
        sortName : 'id',//当数据表格初始化时以哪一列来排序  
        sortOrder : 'asc',//定义排序顺序，可以是'asc'或者'desc'（正序或者倒序）。  
        remoteSort : false,  
            frozenColumns : [ [ {  
            field : 'ck',  
            checkbox : true  
        } ] ], 
        queryParams: {
        	
        },
        onDblClickRow : function(rowIndex, rowData) {
        	console.dir(rowIndex);
        	console.dir(rowData);
        },
        pagination : true,//分页  
        rownumbers : true,//行数
        columns : [[{
			field : 'id',
			title : '记录Id',
			width : 80,
			hidden : true,
			formatter : function(value, row, index) {
				if (row) {
					return row.recId;
				} else {
					return value;
				}
			}},{
			field : 'code',
			title : '邀请码',
			width : 80,
			formatter : function(value, row, index) {
				if (row) {
					return row.code;
				} else {
					return value;
				}
			}},{
			field : 'codeTime',
			title : '生成时间',
			width : 80,
			formatter : function(value, row, index) {
				if (row) {
					return row.codeTime;
				} else {
					return value;
				}
			}},{
			field : 'isUsed',
			title : '使用情况',
			width : 80,
			formatter : function(value, row, index) {
				if (row) {
					if(row.isUsed == 0) {
						return '未使用';
					}else {
						return '已使用';
					}
				} else {
					return value;
				}
			}}]]
    });   
});  
};

var url;
function newInviteCode() {
		$('#dlg').dialog('open').dialog('setTitle', '新建邀请码');
		$('#fm').form('clear');
		url = '';
}

function editInviteCode(){
	var array = $('#table_invitecode').datagrid('getSelections'); 
	if(array.length == 1 ) {
		var row = $('#table_invitecode').datagrid('getSelected');
		if (row != null) {
			$('#dlg').dialog('open').dialog('setTitle', '修改信息');
			$('#fm').form('load', row);
			url = '../inviteCode/updateInviteCode?id=' + row.id;
		}else{
			$.messager.alert('',"请先选择要修改的一行数据！");
		}
	}else{
		$.messager.alert('',"请先选择要修改的一行数据！");  
	}
};

function saveInviteCode() {
	var row = $('#table_invitecode').datagrid('getSelected');
	if($("#fm").form('validate')) {
		$.ajax({
		type : "post",// 使用get方法访问后台
		async: false,
		dataType : "json",// 返回json格式的数据
		url : url,// 要访问的后台地址
		data : {
			'isUsed' : $('#isUsedUpdate').val(),
			},
		success : function(data) {
			if(data.result) {
				$('#dlg').dialog('close'); // close the dialog
				$.messager.alert('提示',data.msg);   
				$('#table_invitecode').datagrid('reload'); // reload the user data
			}else {
				$('#dlg').dialog('close'); // close the dialog
				$.messager.alert('提示',data.msg);   
				$('#table_invitecode').datagrid('reload'); // reload the user data
			}
			
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#dlg').dialog('close'); // close the dialog
			$.messager.alert('提示',"操作失败！");  
		}
		});
	}else {
		$.messager.alert('提示',"表单填写有误！");
	}
};

function destroyInviteCode(){
	var array = $('#table_invitecode').datagrid('getSelections'); 
	console.dir(array);
	var row = $('#table_invitecode').datagrid('getSelected');
	console.dir(row);
	if (row) {
		$.messager.confirm('Confirm',
				'此操作将不可逆!确定删除？', function(r) {
					if (r) {
						var ids = "";
						for( var j = 0; j < array.length; j ++) {
							ids = ids+array[j].id+",";
						}
						$.post('', {
							ids : ids
						}, function(data) {
							if (data.result) {
								$.messager.alert('提示',data.msg);   
								$('#table_invitecode').datagrid('reload'); // reload the user data
							} else {
								$.messager.alert('提示',data.msg);   
								$('#table_invitecode').datagrid('reload'); // reload the user data
							}
						}, 'json');
						}
				});
	}else {
		$.messager.alert('提示',"请至少选择一行数据！");  
	}
};


/**
 * 时间转换函数
 * @param time
 * @returns {String}
 */
function timeStamp2String(time) {
	var datetime = new Date();
	datetime.setTime(time);
	var year = datetime.getFullYear();
	var month = datetime.getMonth() + 1 < 10
			? "0" + (datetime.getMonth() + 1)
			: datetime.getMonth() + 1;
	var date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime
			.getDate();
	var hour = datetime.getHours() < 10 ? "0" + datetime.getHours() : datetime
			.getHours();
	var minute = datetime.getMinutes() < 10
			? "0" + datetime.getMinutes()
			: datetime.getMinutes();
	var second = datetime.getSeconds() < 10
			? "0" + datetime.getSeconds()
			: datetime.getSeconds();
	return year + "-" + month + "-" + date + " " + hour + ":" + minute;
};
/**
 * 将数字保留一位小数
 * @param value
 * @returns {Number}
 */
function formatDecimalOne(value) {
	return Math.floor((value*10))/10;
};