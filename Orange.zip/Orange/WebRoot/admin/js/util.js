/**
 * 获取根目录
 * @return {}
 */
function getRootPath() {
	 var strFullPath=window.document.location.href;
     var strPath=window.document.location.pathname;
     var pos=strFullPath.indexOf(strPath);
     var prePath=strFullPath.substring(0,pos);
     var postPath=strPath.substring(0,strPath.substr(1).indexOf('/')+1);
     var webPath=prePath+postPath;
     return webPath;
}
/**
 * 通过该方法，可以在一个任意深度的iframe中调用父iframe中的方法。
 * 具体到这里就是无论哪一个iframe中的用户访问请求超时，
 * 都可以通过该方法调用最外层iframe中的退出方法，
 * 这样便为用户提供了一个统一的访问超时退出的UI呈现。
 * @return {}
 */
function getRootWin(){
    var win = window;
    while (win != win.parent){
        win = win.parent;
    }
    return win;
}
/**
 * 验证输入框
 */
$.extend($.fn.validatebox.defaults.rules, {    
    eqPwd: {    
        validator: function(value,param){    
            return value == $(param[0]).val();    
        },    
        message: '密码不一致'   
    }
    /*下面可以写更多的验证*/
}); 
