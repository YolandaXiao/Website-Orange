/**
 * 
 */
$(document).ready(function() {
	// extend the 'equals' rule    
	$.extend($.fn.validatebox.defaults.rules, {    
		numberValidate: {    
	        validator: function(value,param){    
	        	 var reg = /^[0-9]*[1-9][0-9]*$/
	             return reg.test(value);      
	        },    
	        message: '请输入整数'   
	    } 
	});
	
	$('#btnGenerate').click(function(){
		if($("#fm").form('validate')) {
			$.ajax({
			type : "post",// 使用get方法访问后台
			async: false,
			dataType : "json",// 返回json格式的数据
			url : '../inviteCode/generateInviteCodes',// 要访问的后台地址
			data : {
				'num':$('#num').val()
				},
			success : function(data) {
				if(data.result) {
					$('#codeArea').val(data.msg);
				}else {
					
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				$.messager.alert('提示',"操作失败！");  
			}
			});
		}else {
			$.messager.alert('提示',"请输入正整数！");
		}
	});
});
