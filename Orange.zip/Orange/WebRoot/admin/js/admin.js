/**
 * 
 */
$(document).ready(function() {
	$.extend($.fn.validatebox.defaults.rules, {    
		equalValidate: {    
	        validator: function(value,param){    
	            return value == $(param[0]).val();    
	        },    
	        message: '密码不一致'   
	    }
	    /*下面可以写更多的验证*/
	}); 
	
	$('#btnChangePwd').click(function(){
		if($("#fm").form('validate')) {
			$.ajax({
			type : "post",// 使用get方法访问后台
			async: false,
			dataType : "json",// 返回json格式的数据
			url : '../admin/validateAdmin',// 要访问的后台地址
			data : {
				'oldPwd':$('#oldPwd').val()
				},
			success : function(data) {
				if(!data.result) {
					$.messager.alert('提示',data.msg);  
					$('#fm').form('clear');
				}else {
					alert(2);
					$.post("../admin/changeAdminPwd", { "newPwd": $('#pwd').val() },
							 function(data){
								if(!data.result) {
									$.messager.alert('提示',data.msg);  
									$('#fm').form('clear');
								}else {
									$.messager.alert('提示',data.msg);
									$('#fm').form('clear');
								}
							 }, "json");
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				$.messager.alert('提示',"操作失败！");  
			}
			});
		}else {
			$.messager.alert('提示',"请检查表单！");
		}
	});
});