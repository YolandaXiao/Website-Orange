/**
 * created on 2014年9月19日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import swjtu.dao.InviteCodeDao;
import swjtu.dao.InviteCodeDaoImpl;
import swjtu.model.InviteCode;
import swjtu.model.TipMessage;
import swjtu.util.GenerStrategy;
import swjtu.util.JSONUtil;

import com.opensymphony.xwork2.ActionSupport;

/**
 * TODO
 * @author ERGOUGE
 * 2014年9月19日 下午12:20:33
 */
public class InviteCodeAction extends ActionSupport{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 主键id
	 */
	private int id;
	/**
	 * 编码
	 */
	private String code;
	/**
	 * 编码生成时间
	 */
	private Date codeTime;
	/**
	 * 是否用完
	 */
	private int isUsed;

	/**
	 * 分页操作的查询页码
	 */
	private int page;
	/**
	 * 分页操作中每页显示的行数
	 */
	private int rows;
	/**
	 * 要删除的id字符串
	 */
	private String ids;
	
	/**
	 * 生成邀请码的个数
	 */
	private int num;
	
	/**
	 * 
	 * 查询邀请码
	 * @author ERGOUGE
	 * 2014年9月19日 下午12:23:00
	 */
	public void findSomeInviteCodes() {
		String sql = "";
		int total = 0;
		InviteCodeDao dao = new InviteCodeDaoImpl();
		List<InviteCode> list = new ArrayList<InviteCode>();
		Map<String, Object> map = new HashMap<String, Object>();
		//如果两个参数都正常接收，则进行sql拼凑，并进行数据库查询
		if(page != 0 && !"".equals(page) && rows != 0 && !"".equals(rows)){
			sql = "select * from invitecode limit " + (page - 1)* rows +"," + (page*rows-1);
			list = dao.findInviteCodesByParams(sql);
			sql = "select count(*) from invitecode";
			total = dao.getToTalItemsNum(sql);
			map.put("total", total);
			map.put("rows", list);
			//将对象转成json字符串
			JSONUtil.writeJson(map);
		}
	}
	
	/**
	 *
	 * 生成指定个数的邀请码
	 * @author ERGOUGE
	 * 2014年9月19日 下午3:43:40
	 */
	public void generateInviteCodes() {
		InviteCodeDao dao = new InviteCodeDaoImpl();
		List<String> list = new ArrayList<String>();
		TipMessage tm = new TipMessage();
		Map<String, Object> map = new HashMap<String, Object>();
		for (int i = 0; i < num; i++) {
			InviteCode iCode = new InviteCode();
			String codeStr = GenerStrategy.generateNumber();
			iCode.setCode(codeStr);
			Date date = new Date();
			iCode.setCodeTime(date.toString());
			iCode.setIsUsed(0);
			list.add(codeStr);//将对象添加到列表，用于输出到前台
			dao.addInviteCode(iCode);//添加到数据库
		}
	//	map.put("total", total);
	//	map.put("rows", list)
		tm.setMsg(list.toString());
		tm.setResult(true);
		tm.setUrl("");
		//将对象转成json字符串
		JSONUtil.writeJson(tm);
	}
	
	/**
	 * 
	 * 删除邀请码信息
	 * @author ERGOUGE
	 * 2014年9月19日 下午5:13:39
	 */
	public void deleteInviteCodes() {
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getCodeTime() {
		return codeTime;
	}

	public void setCodeTime(Date codeTime) {
		this.codeTime = codeTime;
	}

	public int getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(int isUsed) {
		this.isUsed = isUsed;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	
}
