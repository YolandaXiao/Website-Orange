package swjtu.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import swjtu.dao.AvaiTimeOfStudentDao;
import swjtu.dao.AvaiTimeOfStudentDaoImpl;
import swjtu.dao.RelationOfStudent_InterestDao;
import swjtu.dao.RelationOfStudent_InterestDaoImpl;
import swjtu.dao.SeniorDao;
import swjtu.dao.SeniorDaoImpl;
import swjtu.dao.StudentDao;
import swjtu.dao.StudentDaoImpl;
import swjtu.dao.UserDao;
import swjtu.dao.UserDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.AvaiTimeOfStudent;
import swjtu.model.AvailableTimeDic;
import swjtu.model.MailMessage;
import swjtu.model.RelationOfStudent_Interest;
import swjtu.model.SeniorInfo;
import swjtu.model.StuInterestDic;
import swjtu.model.Studentinfo;
import swjtu.model.TipMessage;
import swjtu.model.Weight;
import swjtu.util.DBConn;
import swjtu.util.JSONUtil;
import swjtu.util.Recommendation;
import swjtu.util.SendMail;
import swjtu.util.SendMailImpl;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
/**
 * 跟老人相关的Action
 * @author xzh
 *
 */
public class SeniorAction extends ActionSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9213515712886780812L;

	private SeniorInfo seniorInfo;
	
	private String region;
	private String country;
	private String city_state;
	private SeniorDao seniorDao;
	private RelationOfStudent_InterestDao relationOfStudent_InterestDao;
	private AvaiTimeOfStudentDao avaiTimeOfStudentDao;
	private String interest1;
	private String interest2;
	private String interest3;
	private String interest4;
	private String interest5;
	private String availableTime;
	private String pwd;
	
	private int friendId;
	/**
	 * 分页操作的查询页码
	 */
	private int page;
	/**
	 * 分页操作中每页显示的行数
	 */
	private int rows;
	/**
	 * 要删除的id字符串
	 */
	private String ids;
	
	/**
	 * 添加表单填写信息
	 * @return 
	 */
	public String addSeniorInfo(){
		try {
			boolean result = false;
			String tip ;
			seniorDao = new SeniorDaoImpl();
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			seniorInfo.setAccountInfo(accountInfo);
			seniorInfo.setCountry(country);
			seniorInfo.setEmailAddress(accountInfo.getUserName());
			seniorInfo.setProvince(city_state);
			seniorInfo.setRegion(region);
			/**
			 * 检查有没有值插入
			 */
			SeniorInfo seniorInfo2 = new SeniorInfo();
			String sql = "SELECT * FROM seniorinfo WHERE userId="+accountInfo.getUserId();
			seniorInfo2 = seniorDao.findSeniorInfoByParams(sql);
			if(seniorInfo2!=null){
				return "SeniorExist";
			}
			/**
			 * 插入老人信息表
			 */
			result = seniorDao.addSenior(seniorInfo);
			if(result){
				/**
				 * 插入老人信息表正确
				 */
				relationOfStudent_InterestDao = new RelationOfStudent_InterestDaoImpl();
				RelationOfStudent_Interest relationOfStudent_Interest1 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest2 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest3 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest4 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest5 = new RelationOfStudent_Interest();
				
				StuInterestDic stuInterestDic1 = new StuInterestDic();
				StuInterestDic stuInterestDic2 = new StuInterestDic();
				StuInterestDic stuInterestDic3 = new StuInterestDic();
				StuInterestDic stuInterestDic4 = new StuInterestDic();
				StuInterestDic stuInterestDic5 = new StuInterestDic();
				
				relationOfStudent_Interest1.setAccountInfo(accountInfo);
				stuInterestDic1.setInterestId(Integer.parseInt(interest1));
				relationOfStudent_Interest1.setStuInterestDic(stuInterestDic1);
				relationOfStudent_Interest1.setWeight(Weight.LEVEL_1);
				
				relationOfStudent_Interest2.setAccountInfo(accountInfo);
				stuInterestDic2.setInterestId(Integer.parseInt(interest2));
				relationOfStudent_Interest2.setStuInterestDic(stuInterestDic2);
				relationOfStudent_Interest2.setWeight(Weight.LEVEL_2);
				
				relationOfStudent_Interest3.setAccountInfo(accountInfo);
				stuInterestDic3.setInterestId(Integer.parseInt(interest3));
				relationOfStudent_Interest3.setStuInterestDic(stuInterestDic3);
				relationOfStudent_Interest3.setWeight(Weight.LEVEL_3);
				
				relationOfStudent_Interest4.setAccountInfo(accountInfo);
				stuInterestDic4.setInterestId(Integer.parseInt(interest4));
				relationOfStudent_Interest4.setStuInterestDic(stuInterestDic4);
				relationOfStudent_Interest4.setWeight(Weight.LEVEL_4);
				
				relationOfStudent_Interest5.setAccountInfo(accountInfo);
				stuInterestDic5.setInterestId(Integer.parseInt(interest5));
				relationOfStudent_Interest5.setStuInterestDic(stuInterestDic5);
				relationOfStudent_Interest5.setWeight(Weight.LEVEL_5);
				/**
				 * 插入到学生爱好关联表
				 */
				if(relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest1)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest2)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest3)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest4)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest5)){
					/**
					 * 插入到学生爱好关联表正确
					 */
					String [] avaiTimeId = availableTime.split(", ");
					boolean tag = true;
					for(int i=0;i<avaiTimeId.length;i++){
						AvaiTimeOfStudent  avaiTimeOfStudent = new AvaiTimeOfStudent();
						AvailableTimeDic availableTimeDic = new AvailableTimeDic();
						availableTimeDic.setAvaiTimeId(Integer.parseInt(avaiTimeId[i]));
						avaiTimeOfStudent.setAccountInfo(accountInfo);
						avaiTimeOfStudent.setAvailableTimeDic(availableTimeDic);
						avaiTimeOfStudentDao = new AvaiTimeOfStudentDaoImpl();
						if(!avaiTimeOfStudentDao.addAvaiTimeOfStudent(avaiTimeOfStudent)){
							tag = false;
							break;
						}
					}
					if(tag){
						/**
						 * 插入学生空闲时间表正确
						 */
						return "AddSeniorSUCCESS";
					}else{
						/**
						 * 插入学生空闲时间表错误
						 */
						tip = "插入学生空闲时间表错误";
						ActionContext.getContext().put("tip", tip);
						return "AddSeniorERROR";
					}
					
					
				}else{
					/**
					 * 插入到学生爱好关联表错误
					 */
					tip = "插入到学生爱好关联表错误";
					ActionContext.getContext().put("tip", tip);
					return "AddSeniorERROR";
				}
				
				
				
			}else{
				/**
				 * 插入老人信息表错误
				 */
				tip = "插入老人信息表错误";
				ActionContext.getContext().put("tip", tip);
				return "AddSeniorERROR";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	/**
	 * 
	 * 修改老人信息
	 * @author ERGOUGE
	 * 2014年9月20日 下午1:04:46
	 */
	public String updateSeniorInfo() {
		try {
			boolean result = false;
			String tip ;
			seniorDao = new SeniorDaoImpl();
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			seniorInfo.setAccountInfo(accountInfo);
			seniorInfo.setCountry(country);
			seniorInfo.setEmailAddress(accountInfo.getUserName());
			seniorInfo.setProvince(city_state);
			seniorInfo.setRegion(region);
			/**
			 * 插入老人信息表
			 */
			result = seniorDao.updateSenior(seniorInfo);
			
			if(result){
				//删除爱好关联表的信息
				String sql1 = "delete from relationofstudent_interest where userId="+accountInfo.getUserId();
				DBConn.executeUpdate(sql1);
				/**
				 * 插入老人信息表正确
				 */
				relationOfStudent_InterestDao = new RelationOfStudent_InterestDaoImpl();
				RelationOfStudent_Interest relationOfStudent_Interest1 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest2 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest3 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest4 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest5 = new RelationOfStudent_Interest();
				
				StuInterestDic stuInterestDic1 = new StuInterestDic();
				StuInterestDic stuInterestDic2 = new StuInterestDic();
				StuInterestDic stuInterestDic3 = new StuInterestDic();
				StuInterestDic stuInterestDic4 = new StuInterestDic();
				StuInterestDic stuInterestDic5 = new StuInterestDic();
				
				relationOfStudent_Interest1.setAccountInfo(accountInfo);
				stuInterestDic1.setInterestId(Integer.parseInt(interest1));
				relationOfStudent_Interest1.setStuInterestDic(stuInterestDic1);
				relationOfStudent_Interest1.setWeight(Weight.LEVEL_1);
				
				relationOfStudent_Interest2.setAccountInfo(accountInfo);
				stuInterestDic2.setInterestId(Integer.parseInt(interest2));
				relationOfStudent_Interest2.setStuInterestDic(stuInterestDic2);
				relationOfStudent_Interest2.setWeight(Weight.LEVEL_2);
				
				relationOfStudent_Interest3.setAccountInfo(accountInfo);
				stuInterestDic3.setInterestId(Integer.parseInt(interest3));
				relationOfStudent_Interest3.setStuInterestDic(stuInterestDic3);
				relationOfStudent_Interest3.setWeight(Weight.LEVEL_3);
				
				relationOfStudent_Interest4.setAccountInfo(accountInfo);
				stuInterestDic4.setInterestId(Integer.parseInt(interest4));
				relationOfStudent_Interest4.setStuInterestDic(stuInterestDic4);
				relationOfStudent_Interest4.setWeight(Weight.LEVEL_4);
				
				relationOfStudent_Interest5.setAccountInfo(accountInfo);
				stuInterestDic5.setInterestId(Integer.parseInt(interest5));
				relationOfStudent_Interest5.setStuInterestDic(stuInterestDic5);
				relationOfStudent_Interest5.setWeight(Weight.LEVEL_5);
				/**
				 * 插入到学生爱好关联表
				 */
				if(relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest1)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest2)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest3)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest4)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest5)){
					//删除空闲时间关联表的信息
					String sql2 = "delete from avaitimeofstudent where userId="+accountInfo.getUserId();
					DBConn.executeUpdate(sql2);
					/**
					 * 插入到学生爱好关联表正确
					 */
					String [] avaiTimeId = availableTime.split(", ");
					boolean tag = true;
					for(int i=0;i<avaiTimeId.length;i++){
						AvaiTimeOfStudent  avaiTimeOfStudent = new AvaiTimeOfStudent();
						AvailableTimeDic availableTimeDic = new AvailableTimeDic();
						availableTimeDic.setAvaiTimeId(Integer.parseInt(avaiTimeId[i]));
						avaiTimeOfStudent.setAccountInfo(accountInfo);
						avaiTimeOfStudent.setAvailableTimeDic(availableTimeDic);
						avaiTimeOfStudentDao = new AvaiTimeOfStudentDaoImpl();
						if(!avaiTimeOfStudentDao.addAvaiTimeOfStudent(avaiTimeOfStudent)){
							tag = false;
							break;
						}
					}
					if(tag){
						/**
						 * 插入学生空闲时间表正确
						 */
						return "AddSeniorSUCCESS";
					}else{
						/**
						 * 插入学生空闲时间表错误
						 */
						tip = "插入学生空闲时间表错误";
						ActionContext.getContext().put("tip", tip);
						return "AddSeniorERROR";
					}
					
					
				}else{
					/**
					 * 插入到学生爱好关联表错误
					 */
					tip = "插入到学生爱好关联表错误";
					ActionContext.getContext().put("tip", tip);
					return "AddSeniorERROR";
				}
				
				
				
			}else{
				/**
				 * 插入老人信息表错误
				 */
				tip = "插入老人信息表错误";
				ActionContext.getContext().put("tip", tip);
				return "AddSeniorERROR";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 
	 * 查询老人的信息
	 * @author ERGOUGE
	 * 2014年9月20日 上午10:07:20
	 */
	public void findSomeSeniors() {
		String sql = "";
		int total = 0;
		seniorDao = new SeniorDaoImpl();
		List<SeniorInfo> list = new ArrayList<SeniorInfo>();
		Map<String, Object> map = new HashMap<String, Object>();
		//如果两个参数都正常接收，则进行sql拼凑，并进行数据库查询
		if(page != 0 && !"".equals(page) && rows != 0 && !"".equals(rows)){
			sql = "select * from seniorinfo limit " + (page - 1)* rows +"," + (page*rows-1);
			list = seniorDao.findSomeSeniorsByParams(sql);
			sql = "select count(*) from seniorinfo";
			total = seniorDao.getToTalItemsNum(sql);
			map.put("total", total);
			map.put("rows", list);
			//将对象转成json字符串
			JSONUtil.writeJson(map);
		}
	}

	
	/**
	 * 
	 * 管理员修改老人信息(可以修改)
	 * @author ERGOUGE
	 * 2014年9月19日 上午9:00:45
	 */
	public void updateSeniorByAdmin() {
		String sql = "";
		seniorDao = new SeniorDaoImpl();
		TipMessage tm = new TipMessage();
		String info = "";
		boolean flag1 = false;
		boolean flag2 = false;
		if(seniorInfo.getPreferredName() != null && !"".equals(seniorInfo.getPreferredName()) && seniorInfo.getRecId() != 0 && !"".equals(seniorInfo.getRecId())) {
			sql = "update seniorinfo set preferredName='"+seniorInfo.getPreferredName()+"' where recId=" +seniorInfo.getRecId();
			flag1 = seniorDao.updateSeniorByAdmin(sql);
		}
		if(pwd != null && !"".equals(pwd) && seniorInfo.getEmailAddress() != null && !"".equals(seniorInfo.getEmailAddress())) {
			sql = "update accountinfo set pwd='"+pwd+"' where userName='"+seniorInfo.getEmailAddress()+"'";
			flag2 = seniorDao.updateAccountByAdmin(sql);
		}
		if (flag1) {
			info+="用户昵称更新成功! ";
		} else {
			info+="用户昵称更新失败! ";
		}
		if (flag2) {
			info+="用户密码更新成功! ";
		} else {
			info+="用户密码更新失败或者您未更新! ";
		}
		tm.setMsg(info);
		tm.setUrl("");
		JSONUtil.writeJson(tm);
	}
	
	/**
	 * 
	 * 删除老人信息
	 * @author ERGOUGE
	 * 2014年9月19日 上午10:48:22
	 */
	public void deleteSeniorByAdmin() {
		SeniorDao seniorDao = new SeniorDaoImpl();
		SeniorInfo senior = new SeniorInfo();
		String str[] = {};
		TipMessage tm = new TipMessage();
		if(ids == null || ids.equals("")) {
			tm.setMsg("操作失败");
			tm.setResult(false);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
			return;
		}
		str = ids.split(",");
		String sql = "";//删掉老人信息表中的sql
		String sql2=""; //查找老人信息对应的accountInfo表中的记录
		String sql3 = "";//删除accountInfo表中的相应记录
		boolean flag = true;
		boolean flag2 = true;
		for (int i = 0; i < str.length; i++) {
			sql  = "delete from seniorinfo where recId="+str[i];
		//	sql2 = "select * from seniorinfo where recId="+str[i];
		//	senior = seniorDao.findSeniorInfoByParams(sql2);
		//	sql3 = "delete from accountinfo where userId="+senior.getAccountInfo().getUserId();
			flag = DBConn.deleteRecordByParams(sql);
			//flag2 = DBConn.deleteRecordByParams(sql3);
			if(!flag) {
				break;
			}
		}
		if(flag) {
			tm.setMsg("操作成功");
			tm.setResult(true);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		}else {
			tm.setMsg("操作失败");
			tm.setResult(false);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		}
		
	}
	
	
	/**
	 * 根据session找到老人信息
	 * @return
	 */
	public void findSeniorInfoBySession(){
		try {
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			SeniorInfo seniorInfo = new SeniorInfo();
			seniorDao = new SeniorDaoImpl();
			String sql = "SELECT * FROM seniorinfo WHERE userId="+accountInfo.getUserId();
			seniorInfo = seniorDao.findSeniorInfoByParams(sql);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("seniorInfo", seniorInfo);
			JSONUtil.writeJson(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 根据session找到老人朋友信息
	 */
	public void findSeniorFriendInfoBySession(){
		try {
			UserDao userDao = new UserDaoImpl();
			//由注册进来的老人，session中的friendId还是-1，因此找不到
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			//通过session来找到老人这个对象
		//	String sqlSeniorString = "SELECT * FROM seniorinfo WHERE userId="+accountInfo.getUserId();
			//再声明一个老人的对象
			AccountInfo accountInfo2 = null;
			String sql2 = "SELECT * FROM accountinfo WHERE userId="+accountInfo.getUserId();
			accountInfo2 = userDao.findAccountInfoByParams(sql2);
			
			Studentinfo studentinfo = new Studentinfo();
			//老人朋友账号
			AccountInfo accountInfo1 = new AccountInfo();
			
			String sql = "SELECT * FROM accountinfo WHERE userId="+accountInfo2.getFriendId();
			accountInfo1 = userDao.findAccountInfoByParams(sql);
			StudentDao studentDao = new StudentDaoImpl();
			 sql = "SELECT * FROM studentinfo WHERE userId="+accountInfo1.getUserId();
			 studentinfo = studentDao.findStudentByParams(sql);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("studentinfo", studentinfo);
			JSONUtil.writeJson(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * 调用算法，向前台返回被推荐学生的信息列表
	 * @author ERGOUGE
	 * 2014年9月20日 下午9:45:08
	 * @throws SQLException 
	 */
	public void recommendateStudent() throws SQLException {
		AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
		
		Recommendation db = new Recommendation(accountInfo.getUserId());
        db.ExtractSeniorInterest();
        db.ExtractSeniorTime();
        db.ExtractStudents();
        db.ExtractStudentTime();
        db.ExtractStudentInterest();
        db.matchInterest();
        List<String> lStrings = db.match();
		
		List<AccountInfo> list1 = new ArrayList<AccountInfo>();
		AccountInfo a = new AccountInfo();
	//	int [] array = {14};
		StudentDao dao = new StudentDaoImpl();
		//用户存储空闲时间列表
		AvaiTimeOfStudentDao dao2 = new AvaiTimeOfStudentDaoImpl();
		List<AvaiTimeOfStudent> list2 = new ArrayList<AvaiTimeOfStudent>();
		//用户存储兴趣列表
		RelationOfStudent_InterestDao dao3 = new RelationOfStudent_InterestDaoImpl();
		List<RelationOfStudent_Interest> list5 = new ArrayList<RelationOfStudent_Interest>();
		
		String sqlString  = "";
		
		List<Map<String, Object>> list3 = new ArrayList<Map<String,Object>>();
		for (int i = 0; i < lStrings.size(); i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			Studentinfo s = new Studentinfo();
			sqlString = "select * from studentinfo where userId="+Integer.parseInt(lStrings.get(i));
			s = dao.findStudentByParams(sqlString);
			//判断学生注册之后是否有完善信息，如果用户没有完善信息
			if(s == null) {
				continue;
			}
			map.put("student", s);//放入学生信息
			
			sqlString = "select * from avaitimeofstudent where userId="+Integer.parseInt(lStrings.get(i));
			list2 = dao2.findAvaiTimeOfStudentsByParams(sqlString);
			map.put("time", list2);//放入空闲时间信息
			
			sqlString = "select * from relationofstudent_interest where userId="+Integer.parseInt(lStrings.get(i));
			list5 = dao3.findRelationOfStudent_InterestsByParams(sqlString);
			map.put("interest", list5);
			
			list3.add(map);
		}
		/*List<Studentinfo> list = new ArrayList<Studentinfo>();
		for (int i = 0; i < 3; i++) {
			Studentinfo s = new Studentinfo();
			AccountInfo accountInfo2 = new AccountInfo();
			accountInfo2.setUserId(1);
			accountInfo2.setUserName("1152299040@qq.com");
			s.setAccountInfo(accountInfo2);
			s.setEmailAddress("1152299040@qq.com");
			s.setGender("中性人");
			s.setIntroduction("杀掉");
			s.setSkypeID("ergouge@outlook.com");
			s.setNameCH("冠生疼");
			list.add(s);
		}*/
		List<Map<String, Object>> list4 = new ArrayList<Map<String,Object>>();
		if(list3.size() > 3) {
			for(int i = 0; i < 3; i ++) {
				list4.add(list3.get(i));
			}
		}else {
			list4 = list3;
		}
		JSONUtil.writeJson(list4);
	}
	
	/**
	 * 
	 * 按照accountinfo的id，查找到老人的所有信息，然后发送给指定学生的邮箱中
	 * 然后调用updateAccountInfo()来更新accountinfo表的friendid
	 * @author ERGOUGE
	 * 2014年9月20日 下午9:46:40
	 */
	public void sendEmail(Studentinfo studentinfo) {
/*		MailMessage message = new MailMessage();
        message.setFrom("zuotiba@126.com");
        message.setTo(studentinfo.getEmailAddress());
        message.setSubject("这个是一个邮件发送测试");
        message.setUser("zuotiba");
        //拼凑邮件内容
        message.setContent(studentinfo.getNameCH());
        message.setDatafrom("zuotiba@126.com");
        message.setDatato(studentinfo.getEmailAddress());
        message.setPassword("zuotiba126");
        
        SendMail send = SendMailImpl.getInstance(SendMailImpl.WANGYI126).setMessage(message);*/
		
		SeniorDao dao = new SeniorDaoImpl();
		AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
		String sqlSeniorString = "SELECT * FROM seniorinfo WHERE userId="+accountInfo.getUserId();
		SeniorInfo seniorInfo = dao.findSeniorInfoByParams(sqlSeniorString);
		String contents = "";
        MailMessage message = new MailMessage();
        message.setFrom("orangechatorg@163.com");
        message.setTo(studentinfo.getEmailAddress());
        message.setSubject("Orange社区发送,请勿当作垃圾邮件");
        message.setUser("orangechatorg");
        contents += "Dear " +studentinfo.getNameCH() +",\n\n";
        contents += "We are very glad to tell you that you are successfully paired to the retiree "+seniorInfo.getNameCH()+".\n\n";
        contents += "Here is the skype ID of "+seniorInfo.getSkypeID()+" and we hope that you can contact him/her through Skype message and Email to arrange your first chat!\n\n";
        contents += "Click here to make sure. www.orangechat.org \n\n";
        contents += "If you do not reply within 7 days, we would give the opportunity to other students. \n\n";
        contents += "Now start your exciting chat!\n\n";
        contents += "Best,\n\n";
        contents += "O’rangechat";
        
//        message.setContent("Hello,this is a mail send by O'range! \nThe Senior need your help:\n His/Her email is " + accountInfo.getUserName());
        message.setContent(contents);
//        message.setContent("Hello,this is a mail send by O'range! \nThe Senior need your help:\n"+accountInfo.getUserName());
        message.setDatafrom("orangechatorg@163.com");
        message.setDatato(studentinfo.getEmailAddress());
        message.setPassword("CMUandSLC2014");
        
        SendMail send = SendMailImpl.getInstance(SendMailImpl.WANGYI163).setMessage(message);
        try {
            send.sendMail();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
//		return "updateSeniorSUCCESS";
	
	}
	
	/**
	 * 
	 * 更新accountinfo表的friendid
	 * @author ERGOUGE
	 */
	public void updateAccountInfo() {
		//实例化dao
		seniorDao = new SeniorDaoImpl();
		StudentDao studentDao = new StudentDaoImpl();
		UserDao dao = new UserDaoImpl();
		AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
		boolean flag1 = false;
		boolean flag2 = false;
		//跳转
		String sql = "UPDATE accountinfo SET FriendId="+accountInfo.getUserId()+" WHERE userId="+friendId;
		flag1 = DBConn.executeUpdate(sql);
		sql = "UPDATE accountinfo SET FriendId="+friendId+" WHERE userId="+accountInfo.getUserId();
		flag2 = DBConn.executeUpdate(sql);
		//修改了accountinfo表，即建立了老人和学生之间的一对一关系，然后给相应的学生发送邮件
		/*String sql1 = "SELECT * FROM accountinfo WHERE userId="+friendId;
		accountInfo = dao.findAccountInfoByParams(sql1);*/
		String sql2 = "SELECT * FROM studentinfo WHERE userId="+friendId;
		Studentinfo studentinfo = studentDao.findStudentByParams(sql2);
		if (flag1 && flag2) {
			sendEmail(studentinfo);
			TipMessage tm = new TipMessage();
			tm.setMsg("");
			tm.setUrl("/seniors/SeniorsProfile.jsp");
		}
	//	return "updateSeniorERROR";
	}
	
	/**
	 * 
	 * 按照Session来查找是否存在朋友，没有朋友的话，就跳转到老人选择朋友的界面
	 * @author ERGOUGE
	 * 2014年10月15日 上午8:58:21
	 * @return
	 */
	public String findFriend() {
		UserDao userDao = new UserDaoImpl();
		AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
		AccountInfo accountInfo2 = null;
		String sql2 = "SELECT * FROM accountinfo WHERE userId="+accountInfo.getUserId();
		accountInfo2 = userDao.findAccountInfoByParams(sql2);
		if(accountInfo2.getFriendId() != -1) {
			return "findSuccess";//已有朋友
		} else {
			return "findError";//还没有朋友
		}
	}
	
	public SeniorInfo getSeniorInfo() {
		return seniorInfo;
	}

	public void setSeniorInfo(SeniorInfo seniorInfo) {
		this.seniorInfo = seniorInfo;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getCity_state() {
		return city_state;
	}


	public void setCity_state(String city_state) {
		this.city_state = city_state;
	}


	public String getInterest1() {
		return interest1;
	}


	public void setInterest1(String interest1) {
		this.interest1 = interest1;
	}


	public String getInterest2() {
		return interest2;
	}


	public void setInterest2(String interest2) {
		this.interest2 = interest2;
	}


	public String getInterest3() {
		return interest3;
	}


	public void setInterest3(String interest3) {
		this.interest3 = interest3;
	}


	public String getInterest4() {
		return interest4;
	}

	public void setInterest4(String interest4) {
		this.interest4 = interest4;
	}

	public String getInterest5() {
		return interest5;
	}

	public void setInterest5(String interest5) {
		this.interest5 = interest5;
	}

	public String getAvailableTime() {
		return availableTime;
	}


	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public int getFriendId() {
		return friendId;
	}

	public void setFriendId(int friendId) {
		this.friendId = friendId;
	}
	
}
