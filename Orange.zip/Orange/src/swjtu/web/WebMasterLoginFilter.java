/**
 * created on 2014年9月21日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * TODO
 * @author ERGOUGE
 * 2014年9月21日 下午7:52:35
 */
public class WebMasterLoginFilter implements Filter{  
	  
    public void destroy() {  
          
    }  
  
    public void doFilter(ServletRequest req, ServletResponse res,  
        FilterChain chain) throws IOException, ServletException {  
        HttpServletRequest request = (HttpServletRequest)req;  
        HttpServletResponse response = (HttpServletResponse)res;  
        HttpSession session = request.getSession();  
        String uri = request.getRequestURI();  
        //不过滤登录退出  
        if((!uri.contains("/Home.jsp"))  
        //	&&	(!uri.contains("/Orange/"))
        			&&	(!uri.contains("/login/"))
                && (!uri.contains("/SignUp.jsp"))){  
            if(session.getAttribute("accountinfo") == null){  
              //  response.sendRedirect(request.getContextPath()+"/Orange/Home.jsp");  
                response.sendRedirect("/Orange/Home.jsp");  
                return;  
            }  
        }  
        try{  
            chain.doFilter(req, res);  
        }catch(IllegalStateException e){  
        }  
    }  
  
    public void init(FilterConfig arg0) throws ServletException {  
          
    }  
  
}  
