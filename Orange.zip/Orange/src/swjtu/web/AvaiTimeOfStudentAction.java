package swjtu.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import swjtu.dao.AvaiTimeOfStudentDao;
import swjtu.dao.AvaiTimeOfStudentDaoImpl;
import swjtu.dao.UserDao;
import swjtu.dao.UserDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.AvaiTimeOfStudent;
import swjtu.util.JSONUtil;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class AvaiTimeOfStudentAction extends ActionSupport{
	
	private AvaiTimeOfStudentDao avaiTimeOfStudentDao;
	/**
	 * 根据session找到符合条件的空闲时间
	 */
	public void findAvaiTimeOfStudentsBySession(){
		try {
			ArrayList<AvaiTimeOfStudent> avaiTimeOfStudents = new ArrayList<AvaiTimeOfStudent>();
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			avaiTimeOfStudentDao = new AvaiTimeOfStudentDaoImpl();
			String sql = "SELECT * FROM avaitimeofstudent WHERE userId = "+accountInfo.getUserId()+" ORDER BY avaiTimeId ASC";
			avaiTimeOfStudents = avaiTimeOfStudentDao.findAvaiTimeOfStudentsByParams(sql);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("avaiTimeOfStudents", avaiTimeOfStudents);
			JSONUtil.writeJson(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void findAvaiTimeOfStudentsBySession1(){
		try {
			
			ArrayList<AvaiTimeOfStudent> avaiTimeOfStudents = new ArrayList<AvaiTimeOfStudent>();
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			AccountInfo accountInfo1 = new AccountInfo();
			UserDao userDao = new UserDaoImpl();
			
			//通过注册直接设置的session值，里面的friendId为-1，登录用户不受影响，因此在此处通过accountinfo 的userId获取的老人账号的这个对象，重新赋值
			String sql2 = "SELECT * FROM accountinfo WHERE userId="+accountInfo.getUserId();
			accountInfo = userDao.findAccountInfoByParams(sql2);
			
			
			String sql = "SELECT * FROM accountinfo WHERE userId="+accountInfo.getFriendId();
			accountInfo1 = userDao.findAccountInfoByParams(sql);
			
			avaiTimeOfStudentDao = new AvaiTimeOfStudentDaoImpl();
			 sql = "SELECT * FROM avaitimeofstudent WHERE userId = "+accountInfo1.getUserId()+" ORDER BY avaiTimeId ASC";
			avaiTimeOfStudents = avaiTimeOfStudentDao.findAvaiTimeOfStudentsByParams(sql);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("avaiTimeOfStudents", avaiTimeOfStudents);
			JSONUtil.writeJson(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
