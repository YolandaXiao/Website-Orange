/**
 * 
 */
package swjtu.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import swjtu.dao.SeniorDao;
import swjtu.dao.SeniorDaoImpl;
import swjtu.dao.StudentDao;
import swjtu.dao.StudentDaoImpl;
import swjtu.dao.UserDao;
import swjtu.dao.UserDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.SeniorInfo;
import swjtu.model.Studentinfo;
import swjtu.model.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * 登录事务处理Action
 * @author ERGOUGE
 * @email ergouge@gmail.com
 * 2014年9月6日 下午5:11:02
 */
public class LoginAction extends ActionSupport{
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private User user;
	private UserDao dao;
	private AccountInfo accountInfo;
	private SeniorDao seniorDao;
	private StudentDao studentDao;
	/**
	 * 
	 * 处理登录事务的方法
	 * @author ERGOUGE
	 * 2014年9月6日 下午6:33:57
	 * @return
	 */
	public String login() {
		HttpServletRequest request =ServletActionContext.getRequest();
		//实例化dao
		dao = new UserDaoImpl();
		accountInfo = dao.login(accountInfo);
		//跳转
		if(accountInfo != null){
			String sql1 = "SELECT * FROM accountinfo WHERE userName='"+accountInfo.getUserName()+"'";
			accountInfo = dao.findAccountInfoByParams(sql1);
			ActionContext.getContext().getSession().put("accountInfo", accountInfo);
			if("student".equals(accountInfo.getRole())){
				/**
				 * 根据accountInfo查找学生信息表信息是否存在
				 */
				Studentinfo studentinfo = new Studentinfo();
				studentDao = new StudentDaoImpl();
				String sql = "SELECT * FROM studentinfo WHERE userId="+accountInfo.getUserId();
				studentinfo = studentDao.findStudentByParams(sql);
				
				if(studentinfo!=null){
					if (accountInfo.getFriendId() != -1) {
						return "StudentsHome";//跳转到myfriend页面
					}else {
						/**
						 * 信息已经完善
						 */
						return "StudentInfo";
					}
					
				}else{
					/**
					 * 信息没有完善进入信息完善页面
					 */
					return "Student";
				}
			}else{
				if("seniors".equals(accountInfo.getRole())){
					/**
					 * 根据accountInfo查找老人信息表信息是否存在
					 */
					SeniorInfo seniorInfo = new SeniorInfo();
					seniorDao = new SeniorDaoImpl();
					String sql = "SELECT * FROM seniorinfo WHERE userId="+accountInfo.getUserId();
					seniorInfo = seniorDao.findSeniorInfoByParams(sql);
					
					if(seniorInfo!=null){
						if (accountInfo.getFriendId() != -1) {
							return "SeniorsHomeReal";//跳转到myfriend页面
						}else {
							/**
							 * 信息已经完善
							 */
							return "SeniorInfo";
						}
						
					}else{
						/**
						 * 信息没有完善进入信息完善页面
						 */
						return "Senior";
					}
					
				}else{
					return "Admin";
				}
			}
		} else {
			request.setAttribute("MSG", "用户名或者密码错误");
			return "loginError";
		}
	}
	
	/**
	 * 
	 * 退出系统,清空session值
	 * @author ERGOUGE
	 * 2014年9月20日 下午7:49:36
	 * @return
	 */
	public String exit() {
		ActionContext.getContext().getSession().clear();
		return "exit";
	}
	
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}


	public AccountInfo getAccountInfo() {
		return accountInfo;
	}


	public void setAccountInfo(AccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}
	
	
}
