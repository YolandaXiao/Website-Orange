/**
 * created on 2014年9月19日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.web;

import swjtu.dao.StudentDao;
import swjtu.dao.StudentDaoImpl;
import swjtu.dao.UserDao;
import swjtu.dao.UserDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.TipMessage;
import swjtu.util.JSONUtil;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * TODO
 * @author ERGOUGE
 * 2014年9月19日 下午10:02:06
 */
public class AdminAction extends ActionSupport{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 用户Id
	 */
	private int userId;
	/**
	 * 账号
	 */
	private String userName;
	/**
	 * 密码
	 */
	private String pwd;
	/**
	 * 角色
	 */
	private String role;
	/**
	 * 旧密码
	 */
	private String oldPwd;
	/**
	 * 新密码
	 */
	private String newPwd;

	/**
	 * 
	 * 修改管理员密码
	 * @author ERGOUGE
	 * 2014年9月19日 下午10:04:05
	 */
	public void changeAdminPwd() {
		String sql = "";
		UserDao dao = new UserDaoImpl();
		TipMessage tm = new TipMessage();
		AccountInfo ai = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
		boolean flag = false;
		if(newPwd != null && !"".equals(newPwd) ) {
			sql = "update accountinfo set pwd='"+newPwd+"' where userName='"+ai.getUserName()+"'";
			flag = dao.updateAdminByParams(sql);
		}
		if (flag) {
			tm.setMsg("密码修改成功");
			tm.setResult(true);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		} else {
			tm.setMsg("操作失败");
			tm.setResult(false);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		}
	}
	
	/**
	 * 
	 * 验证管理员密码是否正确
	 * @author ERGOUGE
	 * 2014年9月19日 下午10:21:32
	 */
	public void validateAdmin() {
		UserDao dao = new UserDaoImpl();
		TipMessage tm = new TipMessage();
		AccountInfo ai = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
		if(oldPwd != null && !"".equals(oldPwd) ) {
			ai.setPwd(oldPwd);
		}
		AccountInfo ai2 = dao.login(ai);
		if (ai2 != null) {
			tm.setMsg("密码输入正确");
			tm.setResult(true);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		} else {
			tm.setMsg("密码验证失败");
			tm.setResult(false);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		}
	}
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getNewPwd() {
		return newPwd;
	}

	public void setNewPwd(String newPwd) {
		this.newPwd = newPwd;
	}

	public String getOldPwd() {
		return oldPwd;
	}

	public void setOldPwd(String oldPwd) {
		this.oldPwd = oldPwd;
	}
	
	
	
}
