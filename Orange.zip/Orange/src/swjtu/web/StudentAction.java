/**
 * created on 2014年9月18日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import swjtu.dao.AvaiTimeOfStudentDao;
import swjtu.dao.AvaiTimeOfStudentDaoImpl;
import swjtu.dao.RelationOfStudent_InterestDao;
import swjtu.dao.RelationOfStudent_InterestDaoImpl;
import swjtu.dao.SeniorDao;
import swjtu.dao.SeniorDaoImpl;
import swjtu.dao.StudentDao;
import swjtu.dao.StudentDaoImpl;
import swjtu.dao.UserDao;
import swjtu.dao.UserDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.AvaiTimeOfStudent;
import swjtu.model.AvailableTimeDic;
import swjtu.model.RelationOfStudent_Interest;
import swjtu.model.SeniorInfo;
import swjtu.model.StuInterestDic;
import swjtu.model.Studentinfo;
import swjtu.model.TipMessage;
import swjtu.model.Weight;
import swjtu.util.DBConn;
import swjtu.util.JSONUtil;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * TODO
 * @author ERGOUGE
 * 2014年9月18日 下午9:12:28
 */
public class StudentAction extends ActionSupport{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 记录Id
	 */
	private int recId;
	/**
	 * 学生Id
	 */
	private AccountInfo accountInfo;
	/**
	 * 学生姓名
	 */
	private String nameCH;
	/**
	 * 姓名拼音
	 */
	private String namePinyin;
	/**
	 * 曾用名
	 */
	private String preferredName;
	/**
	 * 性别
	 */
	private String gender;
	/**
	 * 出生年月
	 */
	private String birthday;
	/**
	 * 就读学校
	 */
	private String school;
	/**
	 * 即时通信号码
	 */
	private String skypeID;
	/**
	 * 所在国家
	 */
	private String country;
	/**
	 * 所在省
	 */
	private String city_state;
	/**
	 * 所在部分
	 */
	private String region;
	/**
	 * 邮件地址
	 */
	private String emailAddress;
	/**
	 * 个人简介
	 */
	private String introduction;
	/**
	 * 备注
	 */
	private String memo;

	/**
	 * 分页操作的查询页码
	 */
	private int page;
	/**
	 * 分页操作中每页显示的行数
	 */
	private int rows;
	/**
	 * 账户新密码
	 */
	private String pwd;
	
	/**
	 * 要删除的id字符串
	 */
	private String ids;
	
	private StudentDao studentDao;
	
	private String interest1;
	private String interest2;
	private String interest3;
	private String interest4;
	private String interest5;
	private String availableTime;
	private RelationOfStudent_InterestDao relationOfStudent_InterestDao;
	private AvaiTimeOfStudentDao avaiTimeOfStudentDao;
	/**
	 * 
	 * 完善学生信息
	 * @author xzh
	 * 2014年9月18日 下午9:25:34
	 */
	public String addStudentInfo(){
		try {
			boolean result = false;
			String tip ;
			studentDao = new StudentDaoImpl();
			Studentinfo studentinfo= new Studentinfo();
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			studentinfo.setAccountInfo(accountInfo);
			studentinfo.setBirthday(birthday);
			studentinfo.setCountry(country);
			studentinfo.setEmailAddress(accountInfo.getUserName());
			studentinfo.setGender(gender);
			studentinfo.setIntroduction(introduction);
			studentinfo.setMemo(memo);
			studentinfo.setNameCH(nameCH);
			studentinfo.setNamePinyin(namePinyin);
			studentinfo.setPreferredName(preferredName);
			studentinfo.setProvince(city_state);
			studentinfo.setRegion(region);
			studentinfo.setSchool(school);
			studentinfo.setSkypeID(skypeID);
			/**
			 * 检查有没有值插入
			 */
			Studentinfo studentinfo2 = new Studentinfo();
			String sql = "SELECT * FROM studentinfo WHERE userId="+accountInfo.getUserId();
			studentinfo2 = studentDao.findStudentByParams(sql);
			if(studentinfo2!=null){
				return "StudentExist";
			}
			/**
			 * 插入学生信息表
			 */
			result = studentDao.addStudent(studentinfo);
			if(result){
				/**
				 * 插入学生信息表成功
				 */
				relationOfStudent_InterestDao = new RelationOfStudent_InterestDaoImpl();
				RelationOfStudent_Interest relationOfStudent_Interest1 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest2 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest3 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest4 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest5 = new RelationOfStudent_Interest();
				
				StuInterestDic stuInterestDic1 = new StuInterestDic();
				StuInterestDic stuInterestDic2 = new StuInterestDic();
				StuInterestDic stuInterestDic3 = new StuInterestDic();
				StuInterestDic stuInterestDic4 = new StuInterestDic();
				StuInterestDic stuInterestDic5 = new StuInterestDic();
				
				relationOfStudent_Interest1.setAccountInfo(accountInfo);
				stuInterestDic1.setInterestId(Integer.parseInt(interest1));
				relationOfStudent_Interest1.setStuInterestDic(stuInterestDic1);
				relationOfStudent_Interest1.setWeight(Weight.LEVEL_1);
				
				relationOfStudent_Interest2.setAccountInfo(accountInfo);
				stuInterestDic2.setInterestId(Integer.parseInt(interest2));
				relationOfStudent_Interest2.setStuInterestDic(stuInterestDic2);
				relationOfStudent_Interest2.setWeight(Weight.LEVEL_2);
				
				relationOfStudent_Interest3.setAccountInfo(accountInfo);
				stuInterestDic3.setInterestId(Integer.parseInt(interest3));
				relationOfStudent_Interest3.setStuInterestDic(stuInterestDic3);
				relationOfStudent_Interest3.setWeight(Weight.LEVEL_3);
				
				relationOfStudent_Interest4.setAccountInfo(accountInfo);
				stuInterestDic4.setInterestId(Integer.parseInt(interest4));
				relationOfStudent_Interest4.setStuInterestDic(stuInterestDic4);
				relationOfStudent_Interest4.setWeight(Weight.LEVEL_4);
				
				relationOfStudent_Interest5.setAccountInfo(accountInfo);
				stuInterestDic5.setInterestId(Integer.parseInt(interest5));
				relationOfStudent_Interest5.setStuInterestDic(stuInterestDic5);
				relationOfStudent_Interest5.setWeight(Weight.LEVEL_5);
				/**
				 * 插入到学生爱好关联表
				 */
				if(relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest1)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest2)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest3)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest4)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest5)){
					/**
					 * 插入到学生爱好关联表正确
					 */
					String [] avaiTimeId = availableTime.split(", ");
					boolean tag = true;
					for(int i=0;i<avaiTimeId.length;i++){
						AvaiTimeOfStudent  avaiTimeOfStudent = new AvaiTimeOfStudent();
						AvailableTimeDic availableTimeDic = new AvailableTimeDic();
						availableTimeDic.setAvaiTimeId(Integer.parseInt(avaiTimeId[i]));
						avaiTimeOfStudent.setAccountInfo(accountInfo);
						avaiTimeOfStudent.setAvailableTimeDic(availableTimeDic);
						avaiTimeOfStudentDao = new AvaiTimeOfStudentDaoImpl();
						if(!avaiTimeOfStudentDao.addAvaiTimeOfStudent(avaiTimeOfStudent)){
							tag = false;
							break;
						}
					}
					if(tag){
						/**
						 * 插入学生空闲时间表正确
						 */
						return "AddStudentSUCCESS";
					}else{
						/**
						 * 插入学生空闲时间表错误
						 */
						tip = "插入学生空闲时间表错误";
						ActionContext.getContext().put("tip", tip);
						return "AddStudentERROR";
					}
					
					
				}else{
					/**
					 * 插入到学生爱好关联表错误
					 */
					tip = "插入到学生爱好关联表错误";
					ActionContext.getContext().put("tip", tip);
					return "AddStudentERROR";
				}
				
			}else{
				
				/**
				 * 插入学生信息表失败
				 */
				tip = "插入学生信息表失败";
				ActionContext.getContext().put("tip", tip);
				return "AddStudentERROR";
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 
	 * 查询学生信息，分页查询
	 * @author ERGOUGE
	 * 2014年9月18日 下午9:25:34
	 */
	public void findSomeStudents() {
		String sql = "";
		int total = 0;
		StudentDao dao = new StudentDaoImpl();
		List<Studentinfo> list = new ArrayList<Studentinfo>();
		Map<String, Object> map = new HashMap<String, Object>();
		//如果两个参数都正常接收，则进行sql拼凑，并进行数据库查询
		if(page != 0 && !"".equals(page) && rows != 0 && !"".equals(rows)){
			sql = "select * from studentinfo limit " + (page - 1)* rows +"," + (page*rows-1);
			list = dao.findStudentsByParams(sql);
			sql = "select count(*) from studentinfo";
			total = dao.getToTalItemsNum(sql);
			map.put("total", total);
			map.put("rows", list);
			//将对象转成json字符串
			JSONUtil.writeJson(map);
		}
	}
	
	/**
	 * 
	 * 修改学生信息
	 * @author ERGOUGE
	 * 2014年9月20日 下午1:04:46
	 */
	public String updateStudentInfo() {
		try {
			boolean result = false;
			String tip ;
			studentDao = new StudentDaoImpl();
			Studentinfo studentinfo= new Studentinfo();
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			studentinfo.setAccountInfo(accountInfo);
			studentinfo.setBirthday(birthday);
			studentinfo.setCountry(country);
			studentinfo.setEmailAddress(accountInfo.getUserName());
			studentinfo.setGender(gender);
			studentinfo.setIntroduction(introduction);
			studentinfo.setMemo(memo);
			studentinfo.setNameCH(nameCH);
			studentinfo.setNamePinyin(namePinyin);
			studentinfo.setPreferredName(preferredName);
			studentinfo.setProvince(city_state);
			studentinfo.setRegion(region);
			studentinfo.setSchool(school);
			studentinfo.setSkypeID(skypeID);
			/**
			 * 插入学生信息表
			 */
			result = studentDao.updateStudent(studentinfo);
			if(result){
				//删除爱好关联表的信息
				String sql1 = "delete from relationofstudent_interest where userId="+accountInfo.getUserId();
				DBConn.executeUpdate(sql1);
				
				/**
				 * 修改学生信息表成功
				 */
				relationOfStudent_InterestDao = new RelationOfStudent_InterestDaoImpl();
				RelationOfStudent_Interest relationOfStudent_Interest1 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest2 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest3 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest4 = new RelationOfStudent_Interest();
				RelationOfStudent_Interest relationOfStudent_Interest5 = new RelationOfStudent_Interest();
				
				StuInterestDic stuInterestDic1 = new StuInterestDic();
				StuInterestDic stuInterestDic2 = new StuInterestDic();
				StuInterestDic stuInterestDic3 = new StuInterestDic();
				StuInterestDic stuInterestDic4 = new StuInterestDic();
				StuInterestDic stuInterestDic5 = new StuInterestDic();
				
				relationOfStudent_Interest1.setAccountInfo(accountInfo);
				stuInterestDic1.setInterestId(Integer.parseInt(interest1));
				relationOfStudent_Interest1.setStuInterestDic(stuInterestDic1);
				relationOfStudent_Interest1.setWeight((float)Weight.LEVEL_1);
				
				relationOfStudent_Interest2.setAccountInfo(accountInfo);
				stuInterestDic2.setInterestId(Integer.parseInt(interest2));
				relationOfStudent_Interest2.setStuInterestDic(stuInterestDic2);
				relationOfStudent_Interest2.setWeight((float)Weight.LEVEL_2);
				
				relationOfStudent_Interest3.setAccountInfo(accountInfo);
				stuInterestDic3.setInterestId(Integer.parseInt(interest3));
				relationOfStudent_Interest3.setStuInterestDic(stuInterestDic3);
				relationOfStudent_Interest3.setWeight((float)Weight.LEVEL_3);
				
				relationOfStudent_Interest4.setAccountInfo(accountInfo);
				stuInterestDic4.setInterestId(Integer.parseInt(interest4));
				relationOfStudent_Interest4.setStuInterestDic(stuInterestDic4);
				relationOfStudent_Interest4.setWeight(Weight.LEVEL_4);
				
				relationOfStudent_Interest5.setAccountInfo(accountInfo);
				stuInterestDic5.setInterestId(Integer.parseInt(interest5));
				relationOfStudent_Interest5.setStuInterestDic(stuInterestDic5);
				relationOfStudent_Interest5.setWeight(Weight.LEVEL_5);
				/**
				 * 插入到学生爱好关联表
				 */
				if(relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest1)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest2)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest3)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest4)
						&&relationOfStudent_InterestDao.addRelationOfStudent_Interest(relationOfStudent_Interest5)){
					//删除空闲时间关联表的信息
					String sql2 = "delete from avaitimeofstudent where userId="+accountInfo.getUserId();
					DBConn.executeUpdate(sql2);
					
					/**
					 * 插入到学生爱好关联表正确
					 */
					String [] avaiTimeId = availableTime.split(", ");
					boolean tag = true;
					for(int i=0;i<avaiTimeId.length;i++){
						AvaiTimeOfStudent  avaiTimeOfStudent = new AvaiTimeOfStudent();
						AvailableTimeDic availableTimeDic = new AvailableTimeDic();
						availableTimeDic.setAvaiTimeId(Integer.parseInt(avaiTimeId[i]));
						avaiTimeOfStudent.setAccountInfo(accountInfo);
						avaiTimeOfStudent.setAvailableTimeDic(availableTimeDic);
						avaiTimeOfStudentDao = new AvaiTimeOfStudentDaoImpl();
						if(!avaiTimeOfStudentDao.addAvaiTimeOfStudent(avaiTimeOfStudent)){
							tag = false;
							break;
						}
					}
					if(tag){
						/**
						 * 插入学生空闲时间表正确
						 */
						return "AddStudentSUCCESS";
					}else{
						/**
						 * 插入学生空闲时间表错误
						 */
						tip = "插入学生空闲时间表错误";
						ActionContext.getContext().put("tip", tip);
						return "AddStudentERROR";
					}
					
					
				}else{
					/**
					 * 插入到学生爱好关联表错误
					 */
					tip = "插入到学生爱好关联表错误";
					ActionContext.getContext().put("tip", tip);
					return "AddStudentERROR";
				}
				
			}else{
				
				/**
				 * 插入学生信息表失败
				 */
				tip = "插入学生信息表失败";
				ActionContext.getContext().put("tip", tip);
				return "AddStudentERROR";
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 
	 * 管理员修改学生信息(可以修改)
	 * @author ERGOUGE
	 * 2014年9月19日 上午9:00:45
	 */
	public void updateStudentByAdmin() {
		String sql = "";
		StudentDao dao = new StudentDaoImpl();
		TipMessage tm = new TipMessage();
		String info = "";
		boolean flag1 = false;
		boolean flag2 = false;
		if(preferredName != null && !"".equals(preferredName) && recId != 0 && !"".equals(recId)) {
			sql = "update studentinfo set preferredName='"+preferredName+"' where recId=" +recId;
			flag1 = dao.updateStudentByAdmin(sql);
		}
		if(pwd != null && !"".equals(pwd) && emailAddress != null && !"".equals(emailAddress)) {
			sql = "update accountinfo set pwd='"+pwd+"' where userName='"+emailAddress+"'";
			flag2 = dao.updateAccountByAdmin(sql);
		}
		if (flag1) {
			info+="用户昵称更新成功 ";
		} else {
			info+="用户昵称更新失败 ";
		}
		if (flag2) {
			info+="用户密码更新成功 ";
		} else {
			info+="用户密码更新失败或者您未更新 ";
		}
		tm.setMsg(info);
		tm.setUrl("");
		JSONUtil.writeJson(tm);
		
	}
	
	/**
	 * 
	 * 删除学生信息
	 * @author ERGOUGE
	 * 2014年9月19日 上午10:48:22
	 */
	public void deleteStudentByAdmin() {
		String str[] = {};
		TipMessage tm = new TipMessage();
		if(ids == null || ids.equals("")) {
			tm.setMsg("操作失败");
			tm.setResult(false);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
			return;
		}
		str = ids.split(",");
		String sql = "";
		boolean flag = true;
		for (int i = 0; i < str.length; i++) {
			sql  = "delete from studentinfo where recId="+str[i];
			flag = DBConn.deleteRecordByParams(sql);
			if(!flag) {
				break;
			}
		}
		if(flag) {
			tm.setMsg("操作成功");
			tm.setResult(true);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		}else {
			tm.setMsg("操作失败");
			tm.setResult(false);
			tm.setUrl("");
			JSONUtil.writeJson(tm);
		}
		
	}
	
	/**
	 * 根据session查找学生信息
	 * @return
	 */
	public void findStudentinfoBySession(){
		try {
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			Studentinfo studentinfo = new Studentinfo();
			studentDao = new StudentDaoImpl();
			String sql = "SELECT * FROM studentinfo WHERE userId="+accountInfo.getUserId();
			studentinfo = studentDao.findStudentByParams(sql);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("studentinfo", studentinfo);
			JSONUtil.writeJson(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void findStudentFriendInfoBySession(){
		try {
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			SeniorInfo seniorInfo = new SeniorInfo();
			//学生朋友账号，即老人的对象
			AccountInfo accountInfo1 = new AccountInfo();
			UserDao userDao = new UserDaoImpl();
			
			//再声明一个学生的对象
			AccountInfo accountInfo2 = null;
			String sql2 = "SELECT * FROM accountinfo WHERE userId="+accountInfo.getUserId();
			accountInfo2 = userDao.findAccountInfoByParams(sql2);
			
			if(accountInfo2.getFriendId() != -1) {
				String sql = "SELECT * FROM accountinfo WHERE userId="+accountInfo2.getFriendId();
				accountInfo1 = userDao.findAccountInfoByParams(sql);
				SeniorDao seniorDao = new SeniorDaoImpl();
				 sql = "SELECT * FROM seniorinfo WHERE userId="+accountInfo1.getUserId();
				 seniorInfo = seniorDao.findSeniorInfoByParams(sql);
				 Map<String, Object> map = new HashMap<String, Object>();
				map.put("seniorInfo", seniorInfo);
				JSONUtil.writeJson(map);
			}else {
				TipMessage tm = new TipMessage();
				tm.setMsg("");
				tm.setResult(false);
				JSONUtil.writeJson(tm);
			}
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int getRecId() {
		return recId;
	}

	public void setRecId(int recId) {
		this.recId = recId;
	}

	public AccountInfo getAccountInfo() {
		return accountInfo;
	}

	public void setAccountInfo(AccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}

	public String getNameCH() {
		return nameCH;
	}

	public void setNameCH(String nameCH) {
		this.nameCH = nameCH;
	}

	public String getNamePinyin() {
		return namePinyin;
	}

	public void setNamePinyin(String namePinyin) {
		this.namePinyin = namePinyin;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getSkypeID() {
		return skypeID;
	}

	public void setSkypeID(String skypeID) {
		this.skypeID = skypeID;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}


	public String getCity_state() {
		return city_state;
	}
	public void setCity_state(String city_state) {
		this.city_state = city_state;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}
	public String getInterest1() {
		return interest1;
	}
	public void setInterest1(String interest1) {
		this.interest1 = interest1;
	}
	public String getInterest2() {
		return interest2;
	}
	public void setInterest2(String interest2) {
		this.interest2 = interest2;
	}
	public String getInterest3() {
		return interest3;
	}
	public void setInterest3(String interest3) {
		this.interest3 = interest3;
	}
	
	public String getInterest4() {
		return interest4;
	}
	public void setInterest4(String interest4) {
		this.interest4 = interest4;
	}
	public String getInterest5() {
		return interest5;
	}
	public void setInterest5(String interest5) {
		this.interest5 = interest5;
	}
	public String getAvailableTime() {
		return availableTime;
	}
	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}
	
}
