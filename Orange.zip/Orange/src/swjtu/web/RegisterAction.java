/**
 * 
 */
package swjtu.web;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import swjtu.dao.InviteCodeDao;
import swjtu.dao.InviteCodeDaoImpl;
import swjtu.dao.UserDao;
import swjtu.dao.UserDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.InviteCode;
import swjtu.model.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;


/**
 * 注册事务处理Action
 * @author ERGOUGE
 * @email ergouge@gmail.com
 * 2014年9月6日 下午5:11:15
 */
public class RegisterAction extends ActionSupport{
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private UserDao userDao;//使用域模型接收参数
	private InviteCodeDao inviteCodeDao;
	private User user;
	private AccountInfo accountInfo;
	private InviteCode inviteCode;
	/**
	 * 
	 * 处理注册事务的方法
	 * @author ERGOUGE
	 * 2014年9月6日 下午6:33:33
	 * @return
	 */
	public String register() {
		//实例化dao
		userDao = new UserDaoImpl();
		inviteCodeDao = new InviteCodeDaoImpl();
		boolean result = false;
		accountInfo.setFriendId(-1);
		result = userDao.register(accountInfo);
		//跳转
		if(result){
			/**
			 * 如果用户账号信息表成功删除邀请码
			 */
			if("student".equals(accountInfo.getRole())){
				String sql = "UPDATE invitecode SET isUsed=1 WHERE `code`='"+inviteCode.getCode()+"'";
				result = inviteCodeDao.updateInviteByParams(sql);
				if(result){
					sql = "SELECT * FROM accountinfo WHERE userName='"+accountInfo.getUserName()+"'";
					accountInfo = userDao.findAccountInfoByParams(sql);
					ActionContext.getContext().getSession().put("accountInfo", accountInfo);
						return "Student";
					
					
				}else{
					return ERROR;
				}
			}else{
				String sql = "SELECT * FROM accountinfo WHERE userName='"+accountInfo.getUserName()+"'";
				accountInfo = userDao.findAccountInfoByParams(sql);
				ActionContext.getContext().getSession().put("accountInfo", accountInfo);
				return "Senior";
			}
			
		}else{
			
		}
		return ERROR;
	}
	/**
	 * 是否存在邀请码
	 * @return json
	 */
	public void isInvideCodeExist(){
		try {
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			PrintWriter out = response.getWriter();
			inviteCodeDao = new InviteCodeDaoImpl();
			/**
			 * 比较InviteCode是否存在
			 */
			String invide = inviteCode.getCode();
			String sql = "SELECT * FROM invitecode WHERE `code`='"+invide+"' and isUsed=0 ";
			InviteCode code = inviteCodeDao.findInvideCodeByParams(sql);
			if(code!=null){
				out.println("{\"success\":true,\"msg\":\"拥有邀请码！\"}");
				out.flush();
				out.close();
			}else{
				out.println("{\"success\":false,\"msg\":\"没有邀请码！\"}");
				out.flush();
				out.close();
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 是否存在已注册邮箱
	 * @return json
	 */
	public void isEmailExist(){
		try {
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			PrintWriter out = response.getWriter();
			String sql = "SELECT * FROM accountinfo WHERE userName='"+accountInfo.getUserName()+"'";
			AccountInfo accountInfo1 = new AccountInfo();
			userDao = new UserDaoImpl();
			accountInfo1 = userDao.findAccountInfoByParams(sql);
			if(accountInfo1!=null){
				out.println("{\"success\":false,\"msg\":\"邮箱已经注册！\"}");
				out.flush();
				out.close();
			}else{
				out.println("{\"success\":true,\"msg\":\"邮箱没有注册！！\"}");
				out.flush();
				out.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	public InviteCode getInviteCode() {
		return inviteCode;
	}
	public void setInviteCode(InviteCode inviteCode) {
		this.inviteCode = inviteCode;
	}
	public AccountInfo getAccountInfo() {
		return accountInfo;
	}
	public void setAccountInfo(AccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}
	
	
}
