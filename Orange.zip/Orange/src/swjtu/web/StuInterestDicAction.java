package swjtu.web;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import swjtu.dao.StuInterestDicDao;
import swjtu.dao.StuInterestDicDaoImpl;
import swjtu.model.StuInterestDic;
import swjtu.util.JSONUtil;

import com.opensymphony.xwork2.ActionSupport;

/**
 * 爱好action
 * @author xzh
 *
 */
@SuppressWarnings("serial")
public class StuInterestDicAction extends ActionSupport{
	private String interest1;
	private String interest2;
	private StuInterestDicDao stuInterestDicDao;
	
	/**
	 * 根据条件显示爱好列表（不分页）
	 * @return json
	 */
	public void interestList(){
		try {
			ArrayList<StuInterestDic> stuInterestDics = new ArrayList<StuInterestDic>();
			Map<String, Object> map = new HashMap<String, Object>();
			stuInterestDicDao = new StuInterestDicDaoImpl();
			String sql = "SELECT * FROM stuinterestdic WHERE 1=1";
			if(interest1!=null&&!"".equals(interest1)){
				sql+=" and InterestId<>"+Integer.parseInt(interest1);
			}
			if(interest2!=null&&!"".equals(interest2)){
				sql+=" and InterestId<>"+Integer.parseInt(interest2);
			}
			stuInterestDics = stuInterestDicDao.findStuInterestDicsByParams(sql);
			map.put("rows", stuInterestDics);
			//将对象转成json字符串
			JSONUtil.writeJson(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public String getInterest1() {
		return interest1;
	}

	public void setInterest1(String interest1) {
		this.interest1 = interest1;
	}

	public String getInterest2() {
		return interest2;
	}

	public void setInterest2(String interest2) {
		this.interest2 = interest2;
	}
	
	


}
