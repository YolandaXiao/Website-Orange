package swjtu.model;
/**
 * 用户账号信息表
 * @author xzh
 *
 */
public class AccountInfo {
	/**
	 * 用户Id
	 */
	private int userId;
	/**
	 * 账号
	 */
	private String userName;
	/**
	 * 密码
	 */
	private String pwd;
	/**
	 * 角色
	 */
	private String role;
	/**
	 * 朋友Id
	 */
	private int friendId;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getFriendId() {
		return friendId;
	}
	public void setFriendId(int friendId) {
		this.friendId = friendId;
	}
	
	
	
	

}
