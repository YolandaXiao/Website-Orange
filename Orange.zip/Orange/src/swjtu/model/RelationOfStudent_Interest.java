package swjtu.model;
/**
 * 学生爱好关联表
 * @author xzh
 *
 */
public class RelationOfStudent_Interest {
	/**
	 * 记录Id
	 */
	private int recId;
	/**
	 * 学生Id
	 */
	private AccountInfo accountInfo;
	/**
	 * 爱好Id
	 */
	private StuInterestDic stuInterestDic;
	/**
	 * 爱好程度
	 */
	private float weight;
	public int getRecId() {
		return recId;
	}
	public void setRecId(int recId) {
		this.recId = recId;
	}
	public AccountInfo getAccountInfo() {
		return accountInfo;
	}
	public void setAccountInfo(AccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}
	public StuInterestDic getStuInterestDic() {
		return stuInterestDic;
	}
	public void setStuInterestDic(StuInterestDic stuInterestDic) {
		this.stuInterestDic = stuInterestDic;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	
	
	
	

}
