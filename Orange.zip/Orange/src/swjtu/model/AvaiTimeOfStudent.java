package swjtu.model;
/**
 * 学生空闲时间表
 * @author xzh
 *
 */
public class AvaiTimeOfStudent {
	/**
	 * 记录Id
	 */
	private int recId;
	
	/**
	 * 学生Id
	 */
	private AccountInfo accountInfo;
	/**
	 * 时段Id
	 */
	private AvailableTimeDic availableTimeDic;
	public int getRecId() {
		return recId;
	}
	public void setRecId(int recId) {
		this.recId = recId;
	}
	public AccountInfo getAccountInfo() {
		return accountInfo;
	}
	public void setAccountInfo(AccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}
	public AvailableTimeDic getAvailableTimeDic() {
		return availableTimeDic;
	}
	public void setAvailableTimeDic(AvailableTimeDic availableTimeDic) {
		this.availableTimeDic = availableTimeDic;
	}
	
	
	

}
