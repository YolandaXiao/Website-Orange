package swjtu.model;
/**
 * 空闲时段字典表
 * @author xzh
 *
 */
public class AvailableTimeDic {
	/**
	 * 时段Id
	 */
	private int avaiTimeId;
	/**
	 * 时段名称
	 */
	private String InterestName;

	public int getAvaiTimeId() {
		return avaiTimeId;
	}

	public void setAvaiTimeId(int avaiTimeId) {
		this.avaiTimeId = avaiTimeId;
	}

	public String getInterestName() {
		return InterestName;
	}

	public void setInterestName(String interestName) {
		InterestName = interestName;
	}
	
	
	

}
