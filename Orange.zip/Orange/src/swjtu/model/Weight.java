/**
 * created on 2014年9月20日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.model;

/**
 * 权重
 * @author ERGOUGE
 * 2014年9月20日 下午3:40:51
 */
public class Weight {
	public static final float LEVEL_1 = (float)0.3;
	public static final float LEVEL_2 = (float)0.25;
	public static final float LEVEL_3 = (float)0.2;
	public static final float LEVEL_4 = (float)0.15;
	public static final float LEVEL_5 = (float)0.1;
}
