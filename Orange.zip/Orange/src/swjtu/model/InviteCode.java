package swjtu.model;

import java.util.Date;

/**
 * 邀请码
 * @author Administrator
 *
 */
public class InviteCode {
	/**
	 * 主键id
	 */
	private int id;
	/**
	 * 编码
	 */
	private String code;
	/**
	 * 编码生成时间
	 */
	private String codeTime;
	/**
	 * 是否用完
	 */
	private int isUsed;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getCodeTime() {
		return codeTime;
	}
	public void setCodeTime(String codeTime) {
		this.codeTime = codeTime;
	}
	public int getIsUsed() {
		return isUsed;
	}
	public void setIsUsed(int isUsed) {
		this.isUsed = isUsed;
	}
	
	
	

}
