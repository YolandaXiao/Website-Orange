package swjtu.model;

import java.util.Date;

/**
 * 老人信息表
 * 
 * @author xzh
 * 
 */
public class SeniorInfo {
	/**
	 * 记录Id
	 */
	private int recId;
	/**
	 * 老人Id
	 */
	private AccountInfo accountInfo;
	/**
	 * 老人姓名
	 */
	private String nameCH;
	/**
	 * 昵称
	 */
	private String preferredName;
	/**
	 * 性别
	 */
	private String gender;
	/**
	 * 出生年月
	 */
	private String birthday;
	/**
	 * 所在社区
	 */
	private String school;
	/**
	 * 即时通信号码
	 */
	private String skypeID;
	/**
	 * 所在地区
	 */
	private String region;
	/**
	 * 所在国家
	 */
	private String country;
	/**
	 * 所在省
	 */
	private String province;
	/**
	 * 邮件地址
	 */
	private String emailAddress;
	/**
	 * 备注
	 */
	private String memo;

	public int getRecId() {
		return recId;
	}

	public void setRecId(int recId) {
		this.recId = recId;
	}

	public AccountInfo getAccountInfo() {
		return accountInfo;
	}

	public void setAccountInfo(AccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}

	public String getNameCH() {
		return nameCH;
	}

	public void setNameCH(String nameCH) {
		this.nameCH = nameCH;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getSkypeID() {
		return skypeID;
	}

	public void setSkypeID(String skypeID) {
		this.skypeID = skypeID;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

}
