/**
 * 
 */
package swjtu.model;

/**
 * 用户表对应实体
 * @author ERGOUGE
 * @email ergouge@gmail.com
 * 2014年9月6日 下午5:12:14
 */
public class User {
	private int id;//自增id
	private String stuEmail;//姓名
	private String stuPwd;//密码
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getStuEmail() {
		return stuEmail;
	}
	public void setStuEmail(String stuEmail) {
		this.stuEmail = stuEmail;
	}
	public String getStuPwd() {
		return stuPwd;
	}
	public void setStuPwd(String stuPwd) {
		this.stuPwd = stuPwd;
	}

	
	
}
