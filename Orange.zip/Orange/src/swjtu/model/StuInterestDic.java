package swjtu.model;
/**
 * 兴趣爱好字典表
 * @author xzh
 *
 */
public class StuInterestDic {
	/**
	 * 爱好Id
	 */
	private int interestId;
	/**
	 * 爱好名称
	 */
	private String interestName;
	public int getInterestId() {
		return interestId;
	}
	public void setInterestId(int interestId) {
		this.interestId = interestId;
	}
	public String getInterestName() {
		return interestName;
	}
	public void setInterestName(String interestName) {
		this.interestName = interestName;
	}
	
	
	

}
