package swjtu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import swjtu.model.AccountInfo;
import swjtu.model.SeniorInfo;
import swjtu.util.DBConn;

public class SeniorDaoImpl implements SeniorDao{

	public boolean addSenior(SeniorInfo seniorInfo) {
		// 声明数据库连接
				Connection conn = null;
				// 声明实例
				PreparedStatement pre = null;
				try {
					// 数据库操作字符串
					String sql = "INSERT INTO seniorinfo(userId,NameCH,PreferredName," +
							"Birthday,Gender,School,SkypeID,Region,Country" +
							",Province,EmailAddress,Memo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
					// 获取Connection连接
					conn = DBConn.getConn();
					// 创建实例
					pre = conn.prepareStatement(sql);
					// 设置相关数据项的关联
					// 调用SetPreItems函数，设置相关数据项的关联
					SetPreItems(pre,seniorInfo);

					//添加
					// 返回更新数据库记录条数
					int i = pre.executeUpdate();
					if (i > 0) {
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					// 关闭相关连接
					DBConn.closeStatement(pre);
					DBConn.closeConn(conn);
				}
				return false;
	}

	private void SetPreItems(PreparedStatement pre, SeniorInfo seniorInfo) {
		try {
			
			pre.setInt(1, seniorInfo.getAccountInfo().getUserId());
			pre.setString(2, seniorInfo.getNameCH());
			pre.setString(3,seniorInfo.getPreferredName());
			pre.setString(4,seniorInfo.getBirthday().toString());
			pre.setString(5,seniorInfo.getGender());
			pre.setString(6,seniorInfo.getSchool());
			pre.setString(7,seniorInfo.getSkypeID());
			pre.setString(8,seniorInfo.getRegion());
			pre.setString(9,seniorInfo.getCountry());
			pre.setString(10,seniorInfo.getProvince());
			pre.setString(11,seniorInfo.getEmailAddress());
			pre.setString(12,seniorInfo.getMemo());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public SeniorInfo findSeniorInfoByParams(String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			if (rs.next()) {
				return SetSqlRes(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

	private SeniorInfo SetSqlRes(ResultSet rs) {
		SeniorInfo tmp = new SeniorInfo();
		try {
			//注意：以下字符串名（Id、XJH_Code）需要与数据库表中的字段名完全一致
			AccountInfo accountInfo = new AccountInfo();
			accountInfo.setUserId(rs.getInt("userId"));
			UserDao userDao = new UserDaoImpl();
			String sql = "SELECT * FROM accountinfo WHERE userId="+rs.getInt("userId");
			accountInfo  = userDao.findAccountInfoByParams(sql);
			tmp.setAccountInfo(accountInfo);
			tmp.setBirthday(rs.getString("Birthday"));
			tmp.setCountry(rs.getString("Country"));
			tmp.setEmailAddress(rs.getString("EmailAddress"));
			tmp.setGender(rs.getString("Gender"));
			tmp.setMemo(rs.getString("Memo"));
			tmp.setNameCH(rs.getString("NameCH"));
			tmp.setPreferredName(rs.getString("PreferredName"));
			tmp.setProvince(rs.getString("Province"));
			tmp.setRecId(rs.getInt("RecId"));
			tmp.setRegion(rs.getString("Region"));
			tmp.setSchool(rs.getString("School"));
			tmp.setSkypeID(rs.getString("SkypeID"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.SeniorDao#findSomeSeniorsByParams(java.lang.String)
	 */
	public List<SeniorInfo> findSomeSeniorsByParams(String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		List<SeniorInfo> list = new ArrayList<SeniorInfo>();
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			while (rs.next()) {
				list.add(SetSqlRes(rs));
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.SeniorDao#getToTalItemsNum(java.lang.String)
	 */
	public int getToTalItemsNum(String sql) {
		return DBConn.getToTalItemsNum(sql);
	}

	public boolean updateSeniorByAdmin(String sql) {
		return DBConn.executeUpdate(sql);
	}

	public boolean updateAccountByAdmin(String sql) {
		return DBConn.executeUpdate(sql);
	}

	public boolean updateSenior(SeniorInfo seniorInfo) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "update seniorinfo set NameCH=?,PreferredName=?,Birthday=?,Gender=?,School=?,SkypeID=?,Region=?,Country=?,Province=?,Memo=? where userId=?";
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			pre.setString(1, seniorInfo.getNameCH());
			pre.setString(2,seniorInfo.getPreferredName());
			pre.setString(3,seniorInfo.getBirthday().toString());
			pre.setString(4,seniorInfo.getGender());
			pre.setString(5,seniorInfo.getSchool());
			pre.setString(6,seniorInfo.getSkypeID());
			pre.setString(7,seniorInfo.getRegion());
			pre.setString(8,seniorInfo.getCountry());
			pre.setString(9,seniorInfo.getProvince());
	//		pre.setString(10,seniorInfo.getEmailAddress());
			pre.setString(10,seniorInfo.getMemo());
			pre.setInt(11, seniorInfo.getAccountInfo().getUserId());
			// 获取Connection连接
			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}
	
	

}
