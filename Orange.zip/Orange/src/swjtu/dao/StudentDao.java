/**
 * created on 2014年9月18日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.dao;

import java.util.List;

import swjtu.model.Studentinfo;

/**
 * 学生操作接口
 * @author ERGOUGE
 * 2014年9月18日 下午10:19:17
 */
public interface StudentDao {
	/**
	 * 
	 * 按条件查询学生信息
	 * @author ERGOUGE
	 * 2014年9月18日 下午10:26:41
	 * @return
	 */
	List<Studentinfo> findStudentsByParams(String sql);
	
	/**
	 * 
	 * 查询某一个对象
	 * @author ERGOUGE
	 * 2014年9月18日 下午11:06:05
	 * @param sql
	 * @return 返回值为学生实体
	 */
	Studentinfo findStudentByParams(String sql);

	
	
	/**
	 * 
	 * 删除学生
	 * @author ERGOUGE
	 * 2014年9月18日 下午11:06:22
	 * @param sql
	 * @return 是否删除成功，成功返回true，失败返回false
	 */
	boolean deleteStudentByParams(String sql);
	
	/**
	 * 
	 * 更新学生信息
	 * @author ERGOUGE
	 * 2014年9月18日 下午11:06:26
	 * @param sql
	 * @return
	 */
	boolean updateStudentByParams(String sql);
	
	/**
	 * 
	 * 获得表中所有记录总数
	 * @author ERGOUGE
	 * 2014年9月19日 上午12:03:37
	 * @param sql
	 * @return
	 */
	int getToTalItemsNum(String sql);
	
	/**
	 * 
	 * 管理员修改用户信息（管理员主要是可以修改用户的昵称）
	 * @author ERGOUGE
	 * 2014年9月19日 上午9:19:15
	 * @param sql
	 * @return
	 */
	boolean updateStudentByAdmin(String sql);
	
	/**
	 * 
	 * 管理员修改账户信息表中的密码
	 * @author ERGOUGE
	 * 2014年9月19日 上午9:19:21
	 * @param sql
	 * @return
	 */
	boolean updateAccountByAdmin(String sql);
	/**
	 * 添加学生信息
	 * @param studentinfo
	 * @return
	 */
	boolean addStudent(Studentinfo studentinfo);

	/**
	 * 学生自己修改信息
	 * @author ERGOUGE
	 * 2014年9月20日 下午2:09:45
	 * @param studentinfo
	 * @return
	 */
	boolean updateStudent(Studentinfo studentinfo);
}
