/**
 * 
 */
package swjtu.dao;

import swjtu.model.AccountInfo;
import swjtu.model.InviteCode;
import swjtu.model.User;

/**
 * TODO
 * @author ERGOUGE
 * @email ergouge@gmail.com
 * 2014年9月6日 下午6:28:30
 */
public interface UserDao {
	/**
	 * 
	 * 注册信息，即添加用户
	 * @author ERGOUGE
	 * 2014年9月6日 下午9:55:11
	 * @param accountInfo
	 * @return
	 */
	public boolean register(AccountInfo accountInfo);

	/**
	 * 
	 * 登录操作
	 * @author ERGOUGE
	 * 2014年9月6日 下午9:55:33
	 * @return
	 */
	public AccountInfo login(AccountInfo accountInfo);

	/**
	 * 
	 * 忘记密码
	 * @author ERGOUGE
	 * 2014年9月6日 下午9:58:02
	 * @return
	 */
	public boolean forgetPwd();
	/**
	 * 根据条件选择一条记录
	 * @param sql 
	 * @return
	 */
	public AccountInfo findAccountInfoByParams(String sql);
	
	/**
	 * 
	 * 修改管理员密码
	 * @author ERGOUGE
	 * 2014年9月19日 下午10:08:15
	 * @param sql
	 * @return
	 */
	boolean updateAdminByParams(String sql);
}
