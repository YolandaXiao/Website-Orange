/**
 * created on 2014年9月18日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import swjtu.model.AccountInfo;
import swjtu.model.Studentinfo;
import swjtu.util.DBConn;

/**
 * TODO
 * @author ERGOUGE
 * 2014年9月18日 下午10:27:11
 */
public class StudentDaoImpl implements StudentDao{

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#findStudentsByParams(java.lang.String)
	 */
	public List<Studentinfo> findStudentsByParams(String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		List<Studentinfo> list = new ArrayList<Studentinfo>();
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			while (rs.next()) {
				Studentinfo si = new Studentinfo();
				si.setRecId(rs.getInt("recId"));
		//		si.setAccountInfo(rs.getString(""));
				si.setNameCH(rs.getString("nameCH"));
				si.setNamePinyin(rs.getString("namePinyin"));
				si.setPreferredName(rs.getString("preferredName"));
				si.setGender(rs.getString("gender"));
				si.setBirthday(rs.getString("birthday"));
				si.setSchool(rs.getString("school"));
				si.setSkypeID(rs.getString("skypeID"));
				si.setCountry(rs.getString("country"));
				si.setProvince(rs.getString("province"));
				si.setRegion(rs.getString("region"));
				si.setEmailAddress(rs.getString("emailAddress"));
				si.setIntroduction(rs.getString("introduction"));
				si.setMemo(rs.getString("memo"));
				list.add(si);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#findStudentByParams(java.lang.String)
	 */
	public Studentinfo findStudentByParams(String sql) {
		// 声明数据库连接
				Connection conn = null;
				// 声明实例
				PreparedStatement pre = null;
				// 声明结果集
				java.sql.ResultSet rs = null;
				try {
					// 获取Connection连接
					conn = DBConn.getConn();
					// 创建实例
					pre = conn.prepareStatement(sql);
					rs = pre.executeQuery();
					if (rs.next()) {
						return SetSqlRes(rs);
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					// 关闭相关连接
					DBConn.closeResultSet(rs);
					DBConn.closeStatement(pre);
					DBConn.closeConn(conn);
				}
				return null;
	}

	private Studentinfo SetSqlRes(ResultSet rs) {
		Studentinfo tmp = new Studentinfo();
		try {
			//注意：以下字符串名（Id、XJH_Code）需要与数据库表中的字段名完全一致
			AccountInfo accountInfo = new AccountInfo();
			UserDao userDao = new UserDaoImpl();
			String sql = "SELECT * FROM accountinfo WHERE userId="+rs.getInt("userId");
			accountInfo  = userDao.findAccountInfoByParams(sql);
			tmp.setAccountInfo(accountInfo);
			tmp.setBirthday(rs.getString("Birthday"));
			tmp.setCountry(rs.getString("Country"));
			tmp.setEmailAddress(rs.getString("EmailAddress"));
			tmp.setGender(rs.getString("Gender"));
			tmp.setMemo(rs.getString("Memo"));
			tmp.setNameCH(rs.getString("NameCH"));
			tmp.setPreferredName(rs.getString("PreferredName"));
			tmp.setProvince(rs.getString("Province"));
			tmp.setRecId(rs.getInt("RecId"));
			tmp.setRegion(rs.getString("Region"));
			tmp.setSchool(rs.getString("School"));
			tmp.setSkypeID(rs.getString("SkypeID"));
			tmp.setIntroduction(rs.getString("Introduction"));
			tmp.setNamePinyin(rs.getString("NamePinyin"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#deleteStudentByParams(java.lang.String)
	 */
	public boolean deleteStudentByParams(String sql) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#updateStudentByParams(java.lang.String)
	 */
	public boolean updateStudentByParams(String sql) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#getToTalItemsNum(java.lang.String)
	 */
	public int getToTalItemsNum(String sql) {
		return DBConn.getToTalItemsNum(sql);
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#updateStudentByAdmin(java.lang.String)
	 */
	public boolean updateStudentByAdmin(String sql) {
		return DBConn.executeUpdate(sql);
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.StudentDao#updateAccountByAdmin(java.lang.String)
	 */
	public boolean updateAccountByAdmin(String sql) {
		return DBConn.executeUpdate(sql);
	}

	public boolean addStudent(Studentinfo studentinfo) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "INSERT INTO studentinfo(userId,NameCH,NamePinyin,PreferredName," +
					"Gender,Birthday,School,SkypeID,Country,Province," +
					"Region,EmailAddress,Introduction,Memo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			// 调用SetPreItems函数，设置相关数据项的关联
			SetPreItems(pre,studentinfo);

			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}

	private void SetPreItems(PreparedStatement pre, Studentinfo studentinfo) {
		try {
			pre.setInt(1, studentinfo.getAccountInfo().getUserId());
			pre.setString(2, studentinfo.getNameCH());
			pre.setString(3,studentinfo.getNamePinyin());
			pre.setString(4,studentinfo.getPreferredName());
			pre.setString(5,studentinfo.getGender());
			pre.setString(6,studentinfo.getBirthday());
			pre.setString(7,studentinfo.getSchool());
			pre.setString(8,studentinfo.getSkypeID());
			pre.setString(9,studentinfo.getCountry());
			pre.setString(10,studentinfo.getProvince());
			pre.setString(11,studentinfo.getRegion());
			pre.setString(12,studentinfo.getEmailAddress());
			pre.setString(13,studentinfo.getIntroduction());
			pre.setString(14,studentinfo.getMemo());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public boolean updateStudent(Studentinfo studentinfo) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "update studentinfo set NameCH=?,namePinyin=?,PreferredName=?,Birthday=?,Gender=?,School=?,SkypeID=?,Region=?,Country=?,Province=?,introduction=?,Memo=? where userId=?";
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			// 调用SetPreItems函数，设置相关数据项的关联
			pre.setString(1, studentinfo.getNameCH());
			pre.setString(2, studentinfo.getNamePinyin());
			pre.setString(3, studentinfo.getPreferredName());
			pre.setString(4, studentinfo.getBirthday().toString());
			pre.setString(5, studentinfo.getGender());
			pre.setString(6, studentinfo.getSchool());
			pre.setString(7, studentinfo.getSkypeID());
			pre.setString(8, studentinfo.getRegion());
			pre.setString(9, studentinfo.getCountry());
			pre.setString(10, studentinfo.getProvince());
			pre.setString(11, studentinfo.getIntroduction());
			pre.setString(12, studentinfo.getMemo());
			pre.setInt(13, studentinfo.getAccountInfo().getUserId());
			// 获取Connection连接
			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}
	
	

}
