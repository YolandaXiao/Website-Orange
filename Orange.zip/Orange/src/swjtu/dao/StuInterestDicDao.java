package swjtu.dao;

import java.util.ArrayList;

import swjtu.model.StuInterestDic;

public interface StuInterestDicDao {
	/**
	 * 根据条件筛选爱好信息
	 * @param sql
	 * @return ArrayList<StuInterestDic> stuInterestDics
	 */
	ArrayList<StuInterestDic> findStuInterestDicsByParams(String sql);
	/**
	 * 根据条件筛选爱好信息
	 * @param sql
	 * @return StuInterestDic
	 */
	StuInterestDic findStuInterestDicByParams(String sql);

}
