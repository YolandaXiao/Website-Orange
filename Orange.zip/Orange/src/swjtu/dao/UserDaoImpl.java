/**
 * 
 */
package swjtu.dao;

import java.awt.image.DataBufferUShort;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import swjtu.util.DBConn;
import swjtu.model.AccountInfo;
import swjtu.model.InviteCode;
import swjtu.model.User;

/**
 * UserDao的实现类
 * @author ERGOUGE
 * @email ergouge@gmail.com
 * 2014年9月6日 下午6:31:09
 */
public class UserDaoImpl implements UserDao{

	
	public boolean forgetPwd() {
		// TODO Auto-generated method stub
		return false;
	}


	private AccountInfo SetSqlRes(ResultSet rs) {
		AccountInfo tmp = new AccountInfo();
		try {
			//注意：以下字符串名（Id、XJH_Code）需要与数据库表中的字段名完全一致

			tmp.setUserId(rs.getInt("userId"));
			tmp.setUserName(rs.getString("userName"));
			tmp.setPwd(rs.getString("Pwd"));
			tmp.setRole(rs.getString("Role"));
			tmp.setFriendId(rs.getInt("friendId"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

	public boolean register(AccountInfo accountInfo) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "INSERT INTO accountinfo(userName,Pwd,Role,FriendId) VALUES(?,?,?,?)";
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			// 调用SetPreItems函数，设置相关数据项的关联
			SetPreItems(pre,accountInfo);

			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}


	private void SetPreItems(PreparedStatement pre, AccountInfo accountInfo) {
		try {
			pre.setString(1,accountInfo.getUserName());
			pre.setString(2,accountInfo.getPwd());
			pre.setString(3,accountInfo.getRole());
			pre.setInt(4,accountInfo.getFriendId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	public AccountInfo login(AccountInfo accountInfo) {
		// 声明数据库连接
				Connection conn = null;
				// 声明实例
				PreparedStatement pre = null;
				// 声明结果集
				java.sql.ResultSet rs = null;
				try{
					// 获取Connection连接
					conn = DBConn.getConn();
					String sql = "";
					if (accountInfo != null) {
						String userName = accountInfo.getUserName();
						String Pwd = accountInfo.getPwd();
						if (userName != null && Pwd != null && !"".equalsIgnoreCase(userName)
								&& !"".equalsIgnoreCase(Pwd)) {//userName,userPwd,userGender,userEmail,userPhone,userAge,userGrade
							sql = " select * from accountinfo a where 1=1"
									+ " and  a.userName = '"+ userName + "' and a.Pwd='" + Pwd + "'";
						}
						// 创建实例
						pre = conn.prepareStatement(sql);
						rs = pre.executeQuery();
						if (rs.next()) {
							AccountInfo userInfo = new AccountInfo();
							userInfo.setUserId(rs.getInt("userId"));
							userInfo.setUserName(rs.getString("userName"));
							userInfo.setPwd(rs.getString("Pwd"));
							userInfo.setRole(rs.getString("Role"));
							return userInfo;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return null;
	}


	public AccountInfo findAccountInfoByParams(String sql) {
		// 声明数据库连接
				Connection conn = null;
				// 声明实例
				PreparedStatement pre = null;
				// 声明结果集
				java.sql.ResultSet rs = null;
				try {
					// 获取Connection连接
					conn = DBConn.getConn();
					// 创建实例
					pre = conn.prepareStatement(sql);
					rs = pre.executeQuery();
					if (rs.next()) {
						return SetSqlRes(rs);
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					// 关闭相关连接
					DBConn.closeResultSet(rs);
					DBConn.closeStatement(pre);
					DBConn.closeConn(conn);
				}
				return null;
	}


	/* (non-Javadoc)
	 * @see swjtu.dao.UserDao#updateAdminByParams(java.lang.String)
	 */
	public boolean updateAdminByParams(String sql) {
		return DBConn.executeUpdate(sql);
	}

}
