package swjtu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import swjtu.model.InviteCode;
import swjtu.util.DBConn;

public class InviteCodeDaoImpl implements InviteCodeDao{

	public InviteCode findInvideCodeByParams(String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			if (rs.next()) {
				return SetSqlRes(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

	private InviteCode SetSqlRes(ResultSet rs) {
		InviteCode tmp = new InviteCode();
		try {
			//注意：以下字符串名（Id、XJH_Code）需要与数据库表中的字段名完全一致
			tmp.setId(rs.getInt("id"));
			tmp.setCode(rs.getString("code"));
			tmp.setCodeTime(rs.getString("codeTime"));
			tmp.setIsUsed(rs.getInt("isUsed"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

	public boolean deleteInviteByParams(String sql) {
		return DBConn.deleteRecordByParams(sql);
	}

	public boolean updateInviteByParams(String sql) {
		return DBConn.executeUpdate(sql);
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.InviteCodeDao#getToTalItemsNum(java.lang.String)
	 */
	public int getToTalItemsNum(String sql) {
		return DBConn.getToTalItemsNum(sql);
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.InviteCodeDao#findInviteCodesByParams(java.lang.String)
	 */
	public List<InviteCode> findInviteCodesByParams(String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		List<InviteCode> list = new ArrayList<InviteCode>();
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			while (rs.next()) {
				InviteCode ic = new InviteCode();
				ic.setCode(rs.getString("code"));
				ic.setCodeTime(rs.getString("codeTime"));
				ic.setId(rs.getInt("id"));
				ic.setIsUsed(rs.getInt("isUsed"));
				list.add(ic);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see swjtu.dao.InviteCodeDao#addInvideCode(swjtu.model.InviteCode)
	 */
	public boolean addInviteCode(InviteCode inviteCode) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "INSERT INTO invitecode(code,codeTime,isUsed) VALUES(?,?,?)";
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			// 调用SetPreItems函数，设置相关数据项的关联
			SetPreItems(pre,inviteCode);

			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}

	private void SetPreItems(PreparedStatement pre, InviteCode inviteCode) {
		try {
			pre.setString(1, inviteCode.getCode());
			pre.setString(2, inviteCode.getCodeTime().toString());
			pre.setInt(3, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
