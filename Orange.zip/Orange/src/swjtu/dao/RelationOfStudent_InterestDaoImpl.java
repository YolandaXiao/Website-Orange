package swjtu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.ActionContext;

import swjtu.model.AccountInfo;
import swjtu.model.InviteCode;
import swjtu.model.RelationOfStudent_Interest;
import swjtu.model.StuInterestDic;
import swjtu.util.DBConn;

public class RelationOfStudent_InterestDaoImpl implements RelationOfStudent_InterestDao{

	public boolean addRelationOfStudent_Interest(
			RelationOfStudent_Interest relationOfStudent_Interest1) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "INSERT INTO relationofstudent_interest(userId,InterestId,weight) VALUES(?,?,?)";
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			// 调用SetPreItems函数，设置相关数据项的关联
			SetPreItems(pre,relationOfStudent_Interest1);

			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}

	private void SetPreItems(PreparedStatement pre,
			RelationOfStudent_Interest relationOfStudent_Interest1) {
	try {
			pre.setInt(1, relationOfStudent_Interest1.getAccountInfo().getUserId());
			pre.setInt(2, relationOfStudent_Interest1.getStuInterestDic().getInterestId());
			pre.setFloat(3,relationOfStudent_Interest1.getWeight());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public ArrayList<RelationOfStudent_Interest> findRelationOfStudent_InterestsByParams(
			String sql) {
				// 声明数据库连接
				Connection conn = null;
				// 声明实例
				PreparedStatement pre = null;
				// 声明结果集
				java.sql.ResultSet rs = null;
				ArrayList<RelationOfStudent_Interest> list = new ArrayList<RelationOfStudent_Interest>();
				try {
					// 获取Connection连接
					conn = DBConn.getConn();
					// 创建实例
					pre = conn.prepareStatement(sql);
					rs = pre.executeQuery();
					while (rs.next()) {
						list.add(SetSqlRes(rs));
					}
					return list;
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					// 关闭相关连接
					DBConn.closeResultSet(rs);
					DBConn.closeStatement(pre);
					DBConn.closeConn(conn);
				}
				return null;
	}

	private RelationOfStudent_Interest SetSqlRes(ResultSet rs) {
		RelationOfStudent_Interest tmp = new RelationOfStudent_Interest();
		try {
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			tmp.setAccountInfo(accountInfo);
			/**
			 * 添加stuInterestDic
			 */
			StuInterestDic stuInterestDic = new StuInterestDic();
			StuInterestDicDao stuInterestDicDao = new StuInterestDicDaoImpl();
			int InterestId = rs.getInt("InterestId");
			String sql = "SELECT * FROM stuinterestdic WHERE InterestId ="+InterestId;
			stuInterestDic = stuInterestDicDao.findStuInterestDicByParams(sql);
			tmp.setStuInterestDic(stuInterestDic);
			tmp.setRecId(rs.getInt("RecId"));
			tmp.setWeight(rs.getFloat("weight"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

}
