package swjtu.dao;

import java.util.ArrayList;

import swjtu.model.AvaiTimeOfStudent;

public interface AvaiTimeOfStudentDao {
	/**
	 * 插入学生空闲时间表
	 * @param avaiTimeOfStudent
	 * @return
	 */
	boolean addAvaiTimeOfStudent(AvaiTimeOfStudent avaiTimeOfStudent);
	/**
	 * 根据参数获取学生空余时间表
	 * @param sql
	 * @return
	 */
	ArrayList<AvaiTimeOfStudent> findAvaiTimeOfStudentsByParams(String sql);

}
