package swjtu.dao;

import java.util.ArrayList;

import swjtu.model.RelationOfStudent_Interest;

public interface RelationOfStudent_InterestDao {

	/**
	 * 插入到学生爱好关联表
	 * @param relationOfStudent_Interest1
	 * @return boolean
	 */
	boolean addRelationOfStudent_Interest(
			RelationOfStudent_Interest relationOfStudent_Interest1);
	/**
	 * 根据参数返回对象列表
	 * @param sql
	 * @return ArrayList
	 */
	ArrayList<RelationOfStudent_Interest> findRelationOfStudent_InterestsByParams(
			String sql);
	
	
	

}
