package swjtu.dao;

import java.util.List;

import swjtu.model.SeniorInfo;

public interface SeniorDao {
	/**
	 * 增加老人的信息
	 * @param seniorInfo
	 * @return boolean
	 */
	boolean addSenior(SeniorInfo seniorInfo);
	/**
	 * 根据参数获取老人的信息
	 * @param sql
	 * @return
	 */
	SeniorInfo findSeniorInfoByParams(String sql);
	/**
	 * 根据参数获取老人信息列表
	 * @author ERGOUGE
	 * 2014年9月20日 上午10:12:31
	 * @param sql
	 * @return
	 */
	List<SeniorInfo> findSomeSeniorsByParams(String sql);
	/**
	 * 获取老人的总数
	 * @author ERGOUGE
	 * 2014年9月20日 上午10:12:40
	 * @param sql
	 * @return
	 */
	int getToTalItemsNum(String sql);
	/**
	 * 管理员修改老人的信息(目前主要是修改密码)
	 * @author ERGOUGE
	 * 2014年9月20日 上午10:35:55
	 * @param sql
	 * @return
	 */
	boolean updateSeniorByAdmin(String sql);
	/**
	 * 管理员修改老人账号的密码
	 * @author ERGOUGE
	 * 2014年9月20日 上午10:36:17
	 * @param sql
	 * @return
	 */
	boolean updateAccountByAdmin(String sql);
	/**
	 * 老人自己修改信息
	 * @author ERGOUGE
	 * 2014年9月20日 下午1:32:10
	 * @param seniorInfo
	 * @return
	 */
	boolean updateSenior(SeniorInfo seniorInfo);

}
