package swjtu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import swjtu.model.InviteCode;
import swjtu.model.StuInterestDic;
import swjtu.model.Studentinfo;
import swjtu.util.DBConn;

public class StuInterestDicDaoImpl implements StuInterestDicDao{

	public ArrayList<StuInterestDic> findStuInterestDicsByParams(String sql) {
		// 声明数据库连接
				Connection conn = null;
				// 声明实例
				PreparedStatement pre = null;
				// 声明结果集
				java.sql.ResultSet rs = null;
				ArrayList<StuInterestDic> list = new ArrayList<StuInterestDic>();
				try {
					// 获取Connection连接
					conn = DBConn.getConn();
					// 创建实例
					pre = conn.prepareStatement(sql);
					rs = pre.executeQuery();
					while (rs.next()) {
						
						list.add(SetSqlRes(rs));
					}
					return list;
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					// 关闭相关连接
					DBConn.closeResultSet(rs);
					DBConn.closeStatement(pre);
					DBConn.closeConn(conn);
				}
				return null;
	}

	private StuInterestDic SetSqlRes(ResultSet rs) {
		StuInterestDic tmp = new StuInterestDic();
		try {
			//注意：以下字符串名（Id、XJH_Code）需要与数据库表中的字段名完全一致
			tmp.setInterestId(rs.getInt("InterestId"));
			tmp.setInterestName(rs.getString("InterestName"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

	public StuInterestDic findStuInterestDicByParams(String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			if (rs.next()) {
				
				return SetSqlRes(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

}
