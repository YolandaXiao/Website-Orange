package swjtu.dao;

import java.util.List;

import swjtu.model.InviteCode;

public interface InviteCodeDao {
	/**
	 * 根据参数找到邀请码
	 * @author xzh
	 * 2014年9月19日 下午12:26:44
	 * @param sql
	 * @return
	 */
	InviteCode findInvideCodeByParams(String sql);
	/**
	 * 根据参数删除邀请码
	 * @author xzh
	 * 2014年9月19日 下午12:26:44
	 * @param sql
	 * @return
	 */
	boolean deleteInviteByParams(String sql);
	/**
	 * 根据参数更新邀请码
	 * @author xzh
	 * 2014年9月19日 下午12:26:44
	 * @param sql
	 * @return
	 */
	boolean updateInviteByParams(String sql);

	/**
	 * TODO
	 * @author ERGOUGE
	 * 2014年9月19日 下午12:26:44
	 * @param sql
	 * @return
	 */
	List<InviteCode> findInviteCodesByParams(String sql);

	/**
	 * TODO
	 * @author ERGOUGE
	 * 2014年9月19日 下午12:26:57
	 * @param sql
	 * @return
	 */
	int getToTalItemsNum(String sql);

	boolean addInviteCode(InviteCode inviteCode);
}
