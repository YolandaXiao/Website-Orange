package swjtu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.opensymphony.xwork2.ActionContext;

import swjtu.model.AccountInfo;
import swjtu.model.AvaiTimeOfStudent;
import swjtu.model.AvailableTimeDic;
import swjtu.model.RelationOfStudent_Interest;
import swjtu.model.StuInterestDic;
import swjtu.util.DBConn;

public class AvaiTimeOfStudentDaoImpl implements AvaiTimeOfStudentDao{

	public boolean addAvaiTimeOfStudent(AvaiTimeOfStudent avaiTimeOfStudent) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		try {
			// 数据库操作字符串
			String sql = "INSERT INTO avaitimeofstudent(userId,avaiTimeId) VALUES(?,?)";
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			// 设置相关数据项的关联
			// 调用SetPreItems函数，设置相关数据项的关联
			SetPreItems(pre,avaiTimeOfStudent);

			//添加
			// 返回更新数据库记录条数
			int i = pre.executeUpdate();
			if (i > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return false;
	}

	private void SetPreItems(PreparedStatement pre,
			AvaiTimeOfStudent avaiTimeOfStudent) {
		try {
			pre.setInt(1, avaiTimeOfStudent.getAccountInfo().getUserId());
			pre.setInt(2, avaiTimeOfStudent.getAvailableTimeDic().getAvaiTimeId());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public ArrayList<AvaiTimeOfStudent> findAvaiTimeOfStudentsByParams(
			String sql) {
		// 声明数据库连接
		Connection conn = null;
		// 声明实例
		PreparedStatement pre = null;
		// 声明结果集
		java.sql.ResultSet rs = null;
		ArrayList<AvaiTimeOfStudent> list = new ArrayList<AvaiTimeOfStudent>();
		try {
			// 获取Connection连接
			conn = DBConn.getConn();
			// 创建实例
			pre = conn.prepareStatement(sql);
			rs = pre.executeQuery();
			while (rs.next()) {
				list.add(SetSqlRes(rs));
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭相关连接
			DBConn.closeResultSet(rs);
			DBConn.closeStatement(pre);
			DBConn.closeConn(conn);
		}
		return null;
	}

	private AvaiTimeOfStudent SetSqlRes(ResultSet rs) {
		AvaiTimeOfStudent tmp = new AvaiTimeOfStudent();
		try {
			AccountInfo accountInfo = (AccountInfo) ActionContext.getContext().getSession().get("accountInfo");
			tmp.setAccountInfo(accountInfo);
			/**
			 * 添加stuInterestDic
			 */
			AvailableTimeDic availableTimeDic = new AvailableTimeDic();
			availableTimeDic.setAvaiTimeId(rs.getInt("avaiTimeId"));
			tmp.setAvailableTimeDic(availableTimeDic);
			tmp.setRecId(rs.getInt("RecId"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tmp;
	}

}
