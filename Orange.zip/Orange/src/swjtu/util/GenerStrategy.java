/**
 * created on 2014年9月19日
 * Author ergouge
 * Email ergouge@gmail.com
 * All rights reserved
 */
package swjtu.util;

import java.util.Random;
import java.util.UUID;

/**
 * 邀请码生成策略工具类
 * @author ERGOUGE
 * 2014年9月19日 下午4:17:51
 */
public class GenerStrategy {
	
	/**
	 * 
	 * 生成全部数字的邀请码
	 * @author ERGOUGE
	 * 2014年9月19日 下午4:24:20
	 * @return
	 */
	public static String generateNumber() {
		int max = 9; // 用来产生在[0, max)之间的数
        int prev = 0; // 保持前一个生成的随机数，利用它来让产生的随机数不与前一个数重复
        String code = "";
        Random rand = new Random(System.currentTimeMillis());
        for (int i = 0; i < 10; ++i) {
            int r = (rand.nextInt(max - 1) + 1 + prev) % max;
            prev = r;
            code+=r;
        }
        System.out.print(code);
        return code;
	}
	
	/**
	 * 
	 * UUID作为邀请码
	 * @author ERGOUGE
	 * 2014年9月19日 下午4:25:16
	 * @return
	 */
	public static String generateUUID() {
		 UUID uuid = UUID.randomUUID();
		 String code = uuid.toString();
		 code = code.replace("-", "").substring(0, 10);
		 System.out.println(code);
	     return code;
	}
	
}
