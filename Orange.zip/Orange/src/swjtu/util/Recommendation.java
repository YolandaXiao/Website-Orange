package swjtu.util;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
public class Recommendation{
    //JDBC驱动的位置
 //   private String driver = "com.mysql.jdbc.Driver";
    //测试数据库TestDB的位置
 //   private String url = "jdbc:mysql://127.0.0.1:3306/TestDB";
    //Mysql的用户名和密码
 //   private String user = "yolanda";
 //   private String password = "urawesome";
    //连接句柄
    private Connection conn = null;
    public int senId=1;
	private Map<String,String> senInterest = new 
			HashMap<String, String>();
	public List<String> senTime=new ArrayList<String>();
	public List<String> students=new ArrayList<String>();
	private Map<String,List<String>> stuTime = new 
			HashMap<String, List<String>>();
	private Map<String,Map<String,String>> stuInterest = new 
			HashMap<String, Map<String,String>>();
	public List<Double> similarity=new ArrayList<Double>();
	private Map<String,Double> similarityDic = new 
			HashMap<String, Double>();
	public List<Double> similarityFinal=new ArrayList<Double>();
	public List<String> stuIdsFinal=new ArrayList<String>();
    
 
    /* 构造函数*/
    public Recommendation(){
         
    }
    
    public Recommendation(int senId){
        this.senId = senId;
    }
 
    /*取老人的interest，放在map里 eg.<1,0.3> (<1号兴趣，权值为0.3>)*/
    public void ExtractSeniorInterest() throws SQLException {
        //连接
        connect();
        try {
            //具体如何调用Mysql执行特定sql语句
            Statement statement = conn.createStatement();
            String sqlSen = "select * from relationofstudent_interest where userId="+senId;            
            ResultSet rs = statement.executeQuery(sqlSen);
             
            //遍历select结果
            while(rs.next()){
            	senInterest.put(rs.getString("InterestId"), rs.getString("weight"));
            }
            /*for(Map.Entry<String, String> entry: senInterest.entrySet()){
            	System.out.println(entry.getKey()+","+entry.getValue());
            }*/
        } catch (SQLException e) {
            e.printStackTrace();
        }
 
        close();
    }
    /*老人的time放在list中 ［1，3，6，2］*/
    public void ExtractSeniorTime() throws SQLException {
        //连接
        connect();
        try {
            //具体如何调用Mysql执行特定sql语句
            Statement statement = conn.createStatement();
            String sqlSen = "select * from avaitimeofstudent where userId="+senId;            
            ResultSet rs = statement.executeQuery(sqlSen);
             
            //遍历select结果
            while(rs.next()){
            	senTime.add(rs.getString("avaiTimeId"));
            }
            /*for(int i=0;i<senTime.size();i++){
            	System.out.print(senTime.get(i)+" ");
            }*/
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        close();
    }
    
    /*找到所有studentid，放在list里面*/
    public void ExtractStudents() throws SQLException {
        //连接
        connect();
        try {
            //具体如何调用Mysql执行特定sql语句
            Statement statement = conn.createStatement();
            String sqlSen = "select * from accountinfo where Role='Student'";            
            ResultSet rs = statement.executeQuery(sqlSen);
             
            //遍历select结果
            while(rs.next()){
            	int friendId=rs.getInt("friendId");
            	if(friendId==-1){
            		students.add(rs.getString("userId"));
            	}
            }
            /*for(int i=0;i<students.size();i++){
            	System.out.print(students.get(i)+" ");
            }
            System.out.println();*/
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        close();
    }
    
    /*取学生的时间，放在Map<String,List<String>>中  eg.<2,[3,7,2]> (<学生id,时间的list>)*/
    public void ExtractStudentTime() throws SQLException {
        //连接
        connect();
        try {
            //具体如何调用Mysql执行特定sql语句
            Statement statement = conn.createStatement();
            String sqlSen = "select * from avaitimeofstudent where userId in"+ListtoString(students);            
            ResultSet rs = statement.executeQuery(sqlSen);
    		List<String> Times=new ArrayList<String>();
             
            //遍历select结果
            while(rs.next()){
            	if(stuTime.get(rs.getString("userId"))==null){
            		Times=new ArrayList<String>();	
            	}
            	Times.add(rs.getString("avaiTimeId"));
            	stuTime.put(rs.getString("userId"), Times);            	
            }
            /*for(Map.Entry<String, List<String>> entry: stuTime.entrySet()){
            	System.out.println("stuTime:"+entry.getKey()+","+entry.getValue());
            }
            System.out.println();*/
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        close();
    }
    
    /*取学生的兴趣，放在Map<String,Map<String,String>>中 eg.<2,<1,0.3>>(<2号学生，<1号兴趣，权值0.3>>)*/
    public void ExtractStudentInterest() throws SQLException {
        //连接
        connect();
        try {
            //具体如何调用Mysql执行特定sql语句
            Statement statement = conn.createStatement();
            String sqlSen = "select * from relationofstudent_interest where userId in"+ListtoString(students);          
            ResultSet rs = statement.executeQuery(sqlSen);
            Map<String,String> Interests = new 
        			HashMap<String, String>();
             
            //遍历select结果
            while(rs.next()){
            	if(stuInterest.get(rs.getString("userId"))==null){
            		Interests=new HashMap<String, String>();
            	}
            	Interests.put(rs.getString("InterestId"), rs.getString("weight"));
            	stuInterest.put(rs.getString("userId"), Interests); 
            }
            /*for(Map.Entry<String, Map<String,String>> entry: stuInterest.entrySet()){
            	for(Map.Entry<String,String> e: entry.getValue().entrySet()){
            		System.out.println(entry.getKey()+": <"+e.getKey()+","+e.getValue()+">");
            	}
            }*/
        } catch (SQLException e) {
            e.printStackTrace();
        }
 
        close();
    }
    
    /*匹配时间，返回可用的student的id，放在list里面*/
    public List<String> matchTime(){
    	boolean sign=false;
    	List<String> timeAvaiStu = new ArrayList<String>();
    	for(Map.Entry<String, List<String>> entry: stuTime.entrySet()){
    		for(int j=0;j<senTime.size();j++){
    			for(int i=0;i<entry.getValue().size();i++){
    				if(senTime.get(j).equals(entry.getValue().get(i))){
    					timeAvaiStu.add(entry.getKey());
    					sign=true;
    					break;
    				}
    			}
    			if(sign==true){
    				break;
    			}
    		}
    		sign=false;
    	}
		return timeAvaiStu;
    }
    
    /*取出老人和学生的interest，通过权重计算，把相似度的值分别放入similarity（只储存相似度的list）和similarityDic（把相似度与userId对应）*/
    public void matchInterest(){
    	//Double denominator=0.3*0.3+0.25*0.25+0.2*0.2+0.15*0.15+0.1*0.1;
    	List<String> timeAvaiStu =  matchTime();
    	Double denominator2=0.0;
		for(Map.Entry<String, String> senEntry: senInterest.entrySet()){
			if(senEntry.getKey()!=null){
				denominator2+=Math.pow(Double.parseDouble(senEntry.getValue()),2);
			}
		}
    	for(Map.Entry<String, Map<String,String>> entry: stuInterest.entrySet()){
    		for(int i=0;i<timeAvaiStu.size();i++){
        		if(timeAvaiStu.get(i).equals((entry.getKey()))){
        			//System.out.println(entry.getKey());
        	    	Double numerator = 0.0;
        	    	Double denominator1=0.0;
        			for(Map.Entry<String,String> e: entry.getValue().entrySet()){
        				for(Map.Entry<String, String> senEntry: senInterest.entrySet()){
        					if(e.getKey().equals(senEntry.getKey())){
        						numerator+=Double.parseDouble(e.getValue())*Double.parseDouble(senEntry.getValue());
        					}	
        				}
    					if(e.getKey()!=null){
    						denominator1+=Math.pow(Double.parseDouble(e.getValue()),2);
    					}
        			}
					//System.out.println("denominator1= "+denominator1);
					//System.out.println("denominator2= "+denominator2);					
					//System.out.println("denominator= "+(Math.sqrt(denominator1)*Math.sqrt(denominator2)));
        			Double value=numerator/(Math.sqrt(denominator1)*Math.sqrt(denominator2));
        			System.out.println(value+" id="+entry.getKey());
        			similarity.add(value);
        			similarityDic.put(entry.getKey(),value);
        		}       		
    		}
    	}
    }
    /*public void matchInterest(){
    	Double denominator=0.3*0.3+0.25*0.25+0.2*0.2+0.15*0.15+0.1*0.1;
    	List<String> timeAvaiStu =  matchTime();
    	for(Map.Entry<String, Map<String,String>> entry: stuInterest.entrySet()){
    		for(int i=0;i<timeAvaiStu.size();i++){
        		if(timeAvaiStu.get(i).equals((entry.getKey()))){
        			//System.out.println(entry.getKey());
        	    	Double numerator = 0.0;
        			for(Map.Entry<String,String> e: entry.getValue().entrySet()){
        				for(Map.Entry<String, String> senEntry: senInterest.entrySet()){
        					if(e.getKey().equals(senEntry.getKey())){
        						numerator+=Double.parseDouble(e.getValue())*Double.parseDouble(senEntry.getValue());
        					}
        				}	
        			}
        			System.out.println(numerator/denominator+" id="+entry.getKey());
        			similarity.add(numerator/denominator);
        			similarityDic.put(entry.getKey(), numerator/denominator);
        		}       		
    		}
    	}
    }*/
    
    /*得出最终的三个值，放入stuIdsFinal中。*/
    public List<String> match(){
    	Collections.sort(similarity);
    	int len=3;
    	if(similarity.size()<3){
    		len =similarity.size();
    	}
    	for(int i=0;i<len;i++){
    		similarityFinal.add(similarity.get(similarity.size()-i-1));
    	}
        for(int i=0;i<similarityFinal.size();i++){
        	for(Map.Entry<String, Double> entry: similarityDic.entrySet()){
        		if(entry.getValue().equals(similarityFinal.get(i))){
        			if(!stuIdsFinal.contains(entry.getKey()))
        			stuIdsFinal.add(entry.getKey());
        		}
        	}
        }
        for(int i=0;i<stuIdsFinal.size();i++){
        	System.out.println(stuIdsFinal.get(i));
        }
	return stuIdsFinal;
    }
    
    
    
    
    public String ListtoString(List<String> l){
    	String ids="(";
    	for(int i=0;i<l.size();i++){
    		ids+=l.get(i)+",";
    	}	
    	ids=ids.substring(0,ids.length()-1);
    	ids=ids.concat(")");
    	return ids;
    }


 
    /*
     * Java连接数据库
     */
      public void connect() {
        //加载数据库JDBC驱动
     /*   try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }*/
     
        //利用给定的数据库位置，用户名和密码连接数据库
//        try {
//            conn = DriverManager.getConnection(url, user, password);
        	conn = DBConn.getConn();
            /*if(!conn.isClosed()){
                System.out.println("Succeeded connect to the Database");
            }*/
       /* } catch (SQLException e) {
            e.printStackTrace();
        }*/
         
    }
 
    /* 关闭连接*/
    public void close() throws SQLException {
        conn.close();
    }
         
    /* 主函数 */
 /*   public static void main(String[] args) throws SQLException{
        Recommendation db = new Recommendation();
        db.ExtractSeniorInterest();
        db.ExtractSeniorTime();
        db.ExtractStudents();
        db.ExtractStudentTime();
        db.ExtractStudentInterest();
        db.matchInterest();
        db.match();
    }*/
}