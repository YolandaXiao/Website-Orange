/**
 * 
 */
package swjtu.util;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.opensymphony.xwork2.ActionContext;

import swjtu.dao.SeniorDao;
import swjtu.dao.SeniorDaoImpl;
import swjtu.model.AccountInfo;
import swjtu.model.MailMessage;
import swjtu.model.SeniorInfo;

/**
 * 测试，用于测试某些模块功能
 * @author ERGOUGE
 * @email ergouge@gmail.com
 * 2014年9月7日 上午8:21:06
 */
public class Test {
	public static void main(String[] args) throws SQLException {
/*		MailMessage message = new MailMessage();
        message.setFrom("orangechatorg@yahoo.com");
        message.setTo("ergouge@qq.com");
        message.setSubject("这个是一个邮件发送测试");
        message.setUser("orangechatorg");
        //拼凑邮件内容
        message.setContent("hehe");
        message.setDatafrom("orangechatorg@yahoo.com");
        message.setDatato("ergouge@qq.com");
        message.setPassword("CMUandSLC2014");
        
        SendMail send = SendMailImpl.getInstance(SendMailImpl.YAHOO).setMessage(message);
        try {
            send.sendMail();
        }
        catch (IOException e) {
            e.printStackTrace();
        }*/
      /*  MailMessage message = new MailMessage();
        message.setFrom("zuotiba@126.com");
        message.setTo("845371184@qq.com");
        message.setSubject("这个是一个邮件发送测试");
        message.setUser("zuotiba");
        message.setContent("Hello,this is a mail send test\n你好这是一个邮件发送测试");
        message.setDatafrom("zuotiba@126.com");
        message.setDatato("845371184@qq.com");
        message.setPassword("zuotiba126");
        
        SendMail send = SendMailImpl.getInstance(SendMailImpl.WANGYI126).setMessage(message);
        try {
            send.sendMail();
        }
        catch (IOException e) {
            e.printStackTrace();
        }*/
     /*   MailMessage message = new MailMessage();
        message.setFrom("orangechatorg@163.com");
        message.setTo("845371184@qq.com");
        message.setSubject("Orange社区发送,请勿回复");
        message.setUser("orangechatorg");
        message.setContent("Hello,this is a mail send by O'range! \nThe Senior need your help:\n His/Her email is ergouge@qq.com");
        message.setDatafrom("orangechatorg@163.com");
        message.setDatato("845371184@qq.com");
        message.setPassword("CMUandSLC2014");
        
        SendMail send = SendMailImpl.getInstance(SendMailImpl.WANGYI163).setMessage(message);
        try {
        	send.sendMail();
        }
        catch (IOException e) {
        	e.printStackTrace();
        }*/
		
		/*SeniorDao dao = new SeniorDaoImpl();
		String sqlSeniorString = "SELECT * FROM seniorinfo WHERE userId=16";
		SeniorInfo seniorInfo = dao.findSeniorInfoByParams(sqlSeniorString);
		String contents = "";
        MailMessage message = new MailMessage();
        message.setFrom("orangechatorg@163.com");
        message.setTo("ergouge@qq.com");
        message.setSubject("Orange社区发送,请勿当作垃圾邮件");
        message.setUser("orangechatorg");
        contents += "Dear ergouge,\n\n";
        contents += "We are very glad to tell you that you are successfully paired to the retiree "+seniorInfo.getNameCH()+".\n\n";
        contents += "Here is the skype ID of "+seniorInfo.getSkypeID()+" and we hope that you can contact him/her through Skype message and Email to arrange your first chat!\n\n";
        contents += "Click here to make sure. www.orangechat.org \n\n";
        contents += "If you do not reply within 7 days, we would give the opportunity to other students. \n\n";
        contents += "Now start your exciting chat!\n\n";
        contents += "Best,\n\n";
        contents += "O’rangechat";
        
//        message.setContent("Hello,this is a mail send by O'range! \nThe Senior need your help:\n His/Her email is " + accountInfo.getUserName());
        message.setContent(contents);
//        message.setContent("Hello,this is a mail send by O'range! \nThe Senior need your help:\n"+accountInfo.getUserName());
        message.setDatafrom("orangechatorg@163.com");
        message.setDatato("ergouge@qq.com");
        message.setPassword("CMUandSLC2014");
        
        SendMail send = SendMailImpl.getInstance(SendMailImpl.WANGYI163).setMessage(message);
        try {
            send.sendMail();
        }
        catch (IOException e) {
            e.printStackTrace();
        }*/
		
		/*DBConn dbConn = new DBConn();
		dbConn.getConn();*/
		Recommendation db = new Recommendation(65);
        db.ExtractSeniorInterest();
        db.ExtractSeniorTime();
        db.ExtractStudents();
        db.ExtractStudentTime();
        db.ExtractStudentInterest();
        db.matchInterest();
        List<String> lStrings = db.match();
    }

}
